/**
 * @221 light search index — only fields needed for SKU/batch pick + hit frames.
 * Replace body of getSearchIndex() in WarehouseRead.gs with this logic (keep function name).
 */
function getSearchIndex() {
  var sheets = getInventorySheetList(); // existing helper — returns [{name:...},...]
  var out = [];
  var ss = SpreadsheetApp.openById(PropertiesService.getScriptProperties().getProperty('WAREHOUSE_SHEET_ID') || '1QR6xLZrdSUzhkCNwBhE5EUYpdv8GqkESfj3ELzNf59s');
  // Prefer existing parse path if present:
  if (typeof getEnrichedData === 'function') {
    var all = getEnrichedData(); // may be heavy — prefer sheet-loop below if this is too big
  }
  (sheets || []).forEach(function(s) {
    var name = typeof s === 'string' ? s : (s && s.name);
    if (!name) return;
    var rows;
    try {
      if (typeof parseWarehouseGrid === 'function') {
        rows = parseWarehouseGrid(name);
      } else if (typeof getInventoryBySheet === 'function') {
        rows = getInventoryBySheet(name);
      } else {
        return;
      }
    } catch (e) {
      console.warn('getSearchIndex skip ' + name, e);
      return;
    }
    (rows || []).forEach(function(r) {
      if (!r || !(r.SKU || r.Batch)) return;
      out.push({
        Sheet: r.Sheet || name,
        Slot: r.Slot,
        Depth: r.Depth,
        Level: r.Level,
        SKU: r.SKU || '',
        Batch: r.Batch || '',
        HanhwaCode: r.HanhwaCode || '',
        Brand: r.Brand || '',
        Company: r.Company || '',
        Branches: r.Branches || [],
        PalletKey: r.PalletKey || [r.Sheet || name, r.Slot, r.Depth, r.Level, r.SKU, r.Batch].join('||'),
        BgColor: r.BgColor || '',
        Status: r.Status || ''
      });
    });
  });
  return JSON.stringify(out);
}
