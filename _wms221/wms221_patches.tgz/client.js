
  const state = {
    sheets: [],
    selectedWhTab: "ALL",
    activeSheet: "",
    activeZoneView: null,
    activeSlot: "",
    activeDepth: 0,
    activePalletKey: "",
    activeItemKey: "",
    searchRows: [],
    searchReady: false,
    editingRow: null,
    saving: false,
    zoomScale: 0.65,
    
    movingKey: "",
    movingRow: null,
    movingGroupId: "",
    movingGroupKeys: [],
    moveDestSheet: "",   
    moveDestZoneView: null,
    moveDestSlot: "",
    moveDestDepth: 0,
    moveDestLevel: 1,
    movePending: null,  
    pendingMoves: [],   
    searchPick: { sku: '', batch: '' }  
  };

  const $ = id => document.getElementById(id);

  
  function getOperator() {
    var el = $('operatorInput');
    return (el && el.value.trim()) || localStorage.getItem('wms_operator') || '';
  }
  function saveOperator() {
    var el = $('operatorInput');
    if (!el) return;
    var v = el.value.trim();
    localStorage.setItem('wms_operator', v);
    el.classList.toggle('warn', !v);
  }
  function initOperator() {
    var el = $('operatorInput');
    if (!el) return;
    var saved = localStorage.getItem('wms_operator') || '';
    el.value = saved;
    el.classList.toggle('warn', !saved);
  }
  

  
  var ZONE_LAYOUTS = {
    A: { vw:300, vh:185,
      extras:[ {x:0,y:0,w:26,h:34,fill:'#06101c',label:'WC'}, {x:258,y:0,w:18,h:140,fill:'#020709',label:'PASS',rot:true} ],
      zones:{ A:{x:26,y:0,w:232,h:34,dir:'L',max:38}, B:{x:276,y:0,w:24,h:140,dir:'U',max:10}, C:{x:0,y:34,w:26,h:106,dir:'U',max:27}, D:{x:26,y:34,w:196,h:53,dir:'L',max:27}, E:{x:26,y:87,w:196,h:53,dir:'R',max:14}, F:{x:222,y:34,w:36,h:106,dir:'U',max:28}, G:{x:0,y:155,w:276,h:30,dir:'L',max:35} }
    },
    B: { vw:300, vh:185,
      extras:[ {x:0,y:0,w:26,h:34,fill:'#06101c',label:'WC'}, {x:258,y:0,w:18,h:140,fill:'#020709',label:'PASS',rot:true} ],
      zones:{ A:{x:26,y:0,w:232,h:34,dir:'L',max:38}, B:{x:276,y:0,w:24,h:140,dir:'U',max:6}, C:{x:0,y:34,w:26,h:106,dir:'U',max:20}, D:{x:26,y:34,w:196,h:53,dir:'L',max:36}, E:{x:26,y:87,w:196,h:53,dir:'R',max:37}, F:{x:222,y:34,w:36,h:106,dir:'U',max:11}, G:{x:0,y:155,w:276,h:30,dir:'L',max:40} }
    },
    C: { vw:300, vh:200,
      extras:[ {x:164,y:0,w:22,h:200,fill:'#020709',label:'PASS',rot:true} ],
      zones:{ A:{x:0,y:0,w:26,h:200,dir:'U',max:24}, B:{x:26,y:0,w:38,h:200,dir:'D',max:38}, C:{x:64,y:0,w:34,h:200,dir:'U',max:35}, D:{x:98,y:0,w:34,h:200,dir:'D',max:35}, E:{x:132,y:0,w:32,h:200,dir:'U',max:35}, F:{x:186,y:0,w:34,h:200,dir:'U',max:35}, G:{x:220,y:0,w:40,h:200,dir:'U',max:15}, H:{x:260,y:0,w:40,h:200,dir:'D',max:15} }
    }
  };

  function getMarkerXY(zone, slotNum) {
    var n = Math.max(1, Math.min(slotNum || 1, zone.max));
    var t = zone.max <= 1 ? 0.5 : (n - 1) / (zone.max - 1);
    var x = zone.x, y = zone.y, w = zone.w, h = zone.h, dir = zone.dir;
    var pad = 6;
    if (dir === 'L') return { mx: x + w - pad - t*(w-2*pad), my: y+h/2 };
    if (dir === 'R') return { mx: x + pad + t*(w-2*pad),     my: y+h/2 };
    if (dir === 'U') return { mx: x+w/2, my: y + h - pad - t*(h-2*pad) };
    if (dir === 'D') return { mx: x+w/2, my: y + pad + t*(h-2*pad) };
    return { mx: x+w/2, my: y+h/2 };
  }

  var DIR_ARROW = { L: '←', R: '→', U: '↑', D: '↓' };

  function skuHtml(sku) {
    return esc(String(sku || '-'));
  }

  
  var _mt = { timer: null, startX: 0, startY: 0, dragging: false, ghost: null, overZone: null, suppressTapUntil: 0, touchMoved: false };

  function startMoveMode(palletKey) {
    var row = findRowByKey(palletKey);
    if (!row) return;
    state.activePalletKey = palletKey;
    state.activeItemKey = palletKey;
    if (row.Slot) state.activeSlot = String(row.Slot);
    if (row.Depth) state.activeDepth = Number(row.Depth) || state.activeDepth;
    state.movingKey = palletKey;
    state.movingRow = row;
    state.moveDestSheet = state.activeSheet;
    state.moveDestZoneView = state.activeZoneView;
    
    var groupId = row.PalletGroupId || palletKey;
    state.movingGroupId = groupId;
    var groupKeys = [];
    var zv = state.activeZoneView;
    if (zv) {
      (zv.slots || []).forEach(function(s) {
        (s.pallets || []).forEach(function(p) {
          if ((p.PalletGroupId || p.PalletKey) === groupId) groupKeys.push(p.PalletKey);
        });
      });
    }
    state.movingGroupKeys = groupKeys.length > 0 ? groupKeys : [palletKey];
    state.moveDestSlot = state.activeSlot;   
    state.moveDestDepth = 0;
    state.moveDestLevel = 1;
    if (navigator.vibrate) navigator.vibrate(40);
    state._suppressFocus = true;
    saveViewScroll_();
    renderDetailPanel();
    restoreViewScroll_();
    
    requestAnimationFrame(function() {
      restoreViewScroll_();
      requestAnimationFrame(function() {
        restoreViewScroll_();
        setTimeout(function() {
          restoreViewScroll_();
          state._suppressFocus = false;
        }, 120);
      });
    });
  }

  function cancelMoveMode() {
    if (_mt.timer) { clearTimeout(_mt.timer); _mt.timer = null; }
    
    if (state.saving) {
      state.saving = false;
      hideGridLoading();
    }
    state._suppressFocus = true;
    saveViewScroll_();
    state.movingKey = '';
    state.movingRow = null;
    state.movingGroupId = '';
    state.movingGroupKeys = [];
    state.moveDestSheet = '';
    state.moveDestZoneView = null;
    state.moveDestSlot = '';
    state.moveDestDepth = 0;
    state.movePending = null;
    _destroyGhost();
    closeMoveSlotPicker();
    closeMoveConfirm();
    document.querySelectorAll('.move-bar').forEach(function(el){ el.remove(); });
    document.body.classList.remove('has-move-bar');
    renderDetailPanel();
    restoreViewScroll_();
    requestAnimationFrame(function() {
      restoreViewScroll_();
      setTimeout(function() {
        restoreViewScroll_();
        state._suppressFocus = false;
      }, 80);
    });
  }

  function _destroyGhost() {
    if (_mt.timer) { clearTimeout(_mt.timer); _mt.timer = null; }
    if (_mt.ghost) { _mt.ghost.remove(); _mt.ghost = null; }
    if (_mt.overZone) { _mt.overZone.classList.remove('active'); _mt.overZone = null; }
    _mt.dragging = false;
  }

  function _createGhost(x, y) {
    _destroyGhost();
    var row = state.movingRow;
    if (!row) return;
    var g = document.createElement('div');
    g.className = 'move-ghost';
    g.innerHTML = '<div>' + skuHtml(row.SKU || '-') + '</div><div style="font-size:10px;margin-top:3px;opacity:.8">' + esc(row.Batch || '') + '</div>';
    g.style.left = (x - 55) + 'px';
    g.style.top  = (y - 40) + 'px';
    document.body.appendChild(g);
    _mt.ghost = g;
    _mt.dragging = true;
  }

  
  function _updateGhostPos(x, y) {
    if (_mt.ghost) { _mt.ghost.style.left = (x-55)+'px'; _mt.ghost.style.top = (y-40)+'px'; }
    _mt.ghost && (_mt.ghost.style.pointerEvents = 'none');
    var el = document.elementFromPoint(x, y);
    _mt.ghost && (_mt.ghost.style.pointerEvents = '');
    var zone = el && el.closest ? el.closest('.drop-zone') : null;
    if (zone !== _mt.overZone) {
      if (_mt.overZone) _mt.overZone.classList.remove('active');
      _mt.overZone = zone;
      if (zone) zone.classList.add('active');
    }
  }

  function _dropOnZone() {
    var zone = _mt.overZone;
    _destroyGhost();
    if (!zone) return;
    var d = Number(zone.dataset.depth);
    var l = Number(zone.dataset.level);
    openMoveConfirm(state.activeSlot, d, l);
  }

  
  function openMoveSlotPicker() {
    var row = state.movingRow;
    var meta = $('moveSlotMeta');
    if (meta && row) meta.textContent = (row.SKU || '-') + ' / ' + (row.Batch || '');
    if (!state.moveDestSheet) state.moveDestSheet = state.activeSheet;
    if (!state.moveDestZoneView) state.moveDestZoneView = state.activeZoneView;
    var dp = $('moveDepthPicker');
    if (dp) dp.classList.add('hidden');
    _renderMoveZoneChips();
    _renderMoveSlotList();
    $('moveSlotOverlay').classList.remove('hidden');
  }

  function _renderMoveZoneChips() {
    var zoneRow = $('moveZoneRow');
    if (!zoneRow) return;
    zoneRow.innerHTML = (state.sheets || []).map(function(s) {
      var active = s.name === state.moveDestSheet ? ' selected' : '';
      return '<button class="move-zone-chip' + active + '" onclick="selectMoveSheet(' + JSON.stringify(s.name) + ')">' + esc(s.name) + '</button>';
    }).join('');
  }

  function _renderMoveSlotList() {
    var zv = state.moveDestZoneView;
    var list = $('moveSlotList');
    if (!list) return;
    if (!zv) { list.innerHTML = '<div style="color:var(--muted);font-size:12px;padding:8px">載入中…</div>'; return; }
    var srcRow = state.movingRow;
    list.innerHTML = (zv.slots || []).map(function(s) {
      var isSrc = state.moveDestSheet === (srcRow && srcRow.Sheet) &&
                  s.slotId === (srcRow ? String(srcRow.Slot) : '');
      var sel = isSrc ? ' selected' : '';
      return '<button class="move-slot-chip' + sel + '" data-slotid="' + esc(s.slotId) + '" onclick="selectMoveSlot(' + JSON.stringify(s.slotId) + ')">' +
        esc(s.slotId) + '<small>' + esc(s.palletCount) + '板</small></button>';
    }).join('');
  }

  async function selectMoveSheet(sheetName) {
    state.moveDestSheet = sheetName;
    state.moveDestSlot = '';
    state.moveDestDepth = 0;
    var dp = $('moveDepthPicker');
    if (dp) dp.classList.add('hidden');
    
    var zoneRow = $('moveZoneRow');
    if (zoneRow) zoneRow.querySelectorAll('.move-zone-chip').forEach(function(b) {
      b.classList.toggle('selected', b.textContent === sheetName);
    });
    
    var zv = cacheGet('zone_' + sheetName);
    if (!zv && sheetName === state.activeSheet) zv = state.activeZoneView;
    if (!zv) {
      var list = $('moveSlotList');
      if (list) list.innerHTML = '<div style="color:var(--muted);font-size:12px;padding:8px">載入 ' + esc(sheetName) + '…</div>';
      try {
        zv = await gas('getWarehouseZoneView', sheetName);
        cacheSet('zone_' + sheetName, zv);
      } catch(e) {
        if (list) list.innerHTML = '<div style="color:#ff8f8f;font-size:12px;padding:8px">載入失敗：' + esc(e.message || '') + '</div>';
        return;
      }
    }
    state.moveDestZoneView = zv;
    _renderMoveSlotList();
  }

  function closeMoveSlotPicker() {
    $('moveSlotOverlay').classList.add('hidden');
  }

  function selectMoveSlot(slotId) {
    var list = $('moveSlotList');
    if (list) list.querySelectorAll('.move-slot-chip').forEach(function(b) {
      b.classList.toggle('selected', b.dataset.slotid === slotId);
    });
    state.moveDestSlot = slotId;
    var zv = state.moveDestZoneView;
    var slot = (zv && zv.slots) ? zv.slots.find(function(s){ return s.slotId === slotId; }) : null;
    var maxD = slot ? slot.maxDepth : (zv ? zv.maxDepth : 5);
    var dp = $('moveDepthPicker');
    if (!dp) return;
    dp.innerHTML = '<span style="font-size:12px;color:var(--muted);font-weight:700;width:100%">選擇目標排：</span>' +
      Array.from({length: Math.max(maxD, 5)}, function(_, i) {
        var d = i + 1;
        return '<button class="move-depth-chip" data-depth="' + d + '" onclick="selectMoveDepth(' + d + ')">' + depthLabel(d) + '</button>';
      }).join('');
    dp.classList.remove('hidden');
  }

  function selectMoveDepth(depth) {
    var dp = $('moveDepthPicker');
    if (dp) dp.querySelectorAll('.move-depth-chip').forEach(function(b) {
      b.classList.toggle('selected', Number(b.dataset.depth) === depth);
    });
    state.moveDestDepth = depth;
    closeMoveSlotPicker();
    var zv = state.moveDestZoneView;
    var destSlotObj = zv && zv.slots ? zv.slots.find(function(s){ return s.slotId === state.moveDestSlot; }) : null;
    var existingCount = 0;
    if (destSlotObj) {
      var dd = (destSlotObj.depths || []).find(function(d){ return d.depth === depth; });
      existingCount = dd ? (dd.pallets || []).length : 0;
    }
    openMoveConfirm(state.moveDestSlot, depth, existingCount + 1);
  }

  function executeDirectMove(destSlot, destDepth, destLevel) {
    if (state.saving || state._moveTapLock) return;
    if (!state.movingKey || !state.movingRow) {
      setStatus('請先長按棧板進入移動模式', 'err');
      return;
    }
    
    if (_mt.touchMoved) {
      _mt.touchMoved = false;
      return;
    }
    destSlot = String(destSlot || state.activeSlot || '');
    destDepth = Number(destDepth);
    destLevel = Number(destLevel) || 1;
    if (!destSlot || destDepth < 1) {
      setStatus('目標位置無效', 'err');
      return;
    }
    state._moveTapLock = true;
    setTimeout(function(){ state._moveTapLock = false; }, 1200);
    
    queueLocalMove_(destSlot, destDepth, destLevel);
  }

  function queueLocalMove_(destSlot, destDepth, destLevel) {
    var src = state.movingRow;
    if (!src) return;
    var destSheet = state.moveDestSheet || state.activeSheet;
    var entry = {
      palletKey: state.movingKey,
      groupKeys: (state.movingGroupKeys || []).slice(),
      sourceSheet: src.Sheet,
      destSheet: destSheet,
      destSlot: String(destSlot),
      destDepth: Number(destDepth),
      destLevel: Number(destLevel) || 1,
      sku: src.SKU,
      batch: src.Batch
    };
    
    applyLocalMoveToZone_(entry);
    state.pendingMoves.push(entry);
    
    var keepSlot = state.activeSlot;
    var keepDepth = state.activeDepth;
    state.movingKey = '';
    state.movingRow = null;
    state.movingGroupKeys = [];
    document.querySelectorAll('.move-bar').forEach(function(el){ el.remove(); });
    document.body.classList.remove('has-move-bar');
    renderDetailPanel();
    renderOverviewTable();
    renderPendingSaveBar_();
    setStatus('已暫存移動 ' + state.pendingMoves.length + ' 筆（尚未寫入試算表）— 按「全部存檔」一次寫入', 'ok');
  }

  function applyLocalMoveToZone_(entry) {
    var zv = state.activeZoneView;
    if (!zv || entry.sourceSheet !== zv.sheet) return;
    var moved = null;
    (zv.slots || []).forEach(function(slot) {
      (slot.depths || []).forEach(function(d) {
        var next = [];
        (d.pallets || []).forEach(function(p) {
          if (p.PalletKey === entry.palletKey || (entry.groupKeys || []).indexOf(p.PalletKey) >= 0) {
            moved = p;
          } else next.push(p);
        });
        d.pallets = next;
      });
      
      if (slot.pallets) {
        slot.pallets = (slot.pallets || []).filter(function(p) {
          if (p.PalletKey === entry.palletKey || (entry.groupKeys || []).indexOf(p.PalletKey) >= 0) {
            moved = moved || p;
            return false;
          }
          return true;
        });
      }
    });
    if (!moved) return;
    var destSlotObj = (zv.slots || []).find(function(s){ return String(s.slotId) === String(entry.destSlot); });
    if (!destSlotObj) return;
    if (!destSlotObj.depths) destSlotObj.depths = [];
    var dd = destSlotObj.depths.find(function(d){ return Number(d.depth) === Number(entry.destDepth); });
    if (!dd) {
      dd = { depth: Number(entry.destDepth), label: depthLabel(entry.destDepth), pallets: [], maxPallets: 0 };
      destSlotObj.depths.push(dd);
    }
    moved = Object.assign({}, moved);
    moved.Slot = entry.destSlot;
    moved.Depth = entry.destDepth;
    moved.Level = entry.destLevel;
    moved.Sheet = entry.destSheet;
    moved.PalletKey = [entry.destSheet, entry.destSlot, entry.destDepth, entry.destLevel, moved.SKU, moved.Batch].join('||');
    moved.UpdatedAt = new Date().toISOString();
    var ins = Math.max(0, Math.min((entry.destLevel || 1) - 1, dd.pallets.length));
    dd.pallets.splice(ins, 0, moved);
    state.recentlyMovedKey = moved.PalletKey;
  }

  function renderPendingSaveBar_() {
    var old = document.getElementById('pendingSaveBar');
    if (old) old.remove();
    var n = (state.pendingMoves || []).length;
    if (!n) return;
    var bar = document.createElement('div');
    bar.id = 'pendingSaveBar';
    bar.className = 'pending-save-bar';
    bar.innerHTML = '<span>待存檔 <strong>' + n + '</strong> 筆移動</span>' +
      '<button type="button" class="pending-save-btn" onclick="flushPendingMoves()">全部存檔</button>' +
      '<button type="button" class="pending-discard-btn" onclick="discardPendingMoves()">丟棄</button>';
    document.body.appendChild(bar);
    document.body.classList.add('has-pending-save');
  }

  async function flushPendingMoves() {
    if (!state.pendingMoves.length || state.saving) return;
    state.saving = true;
    showGridLoading('一次寫入 ' + state.pendingMoves.length + ' 筆移動…');
    setStatus('批次存檔中…', 'loading');
    var moves = state.pendingMoves.slice();
    try {
      var result = await gas('movePalletBatch', { moves: moves, operator: getOperator() });
      state.pendingMoves = [];
      renderPendingSaveBar_();
      document.body.classList.remove('has-pending-save');
      if (result && result.history) applyHistory_(result.history);
      if (result && result.zoneView) {
        cacheSet('zone_' + result.zoneView.sheet, result.zoneView);
        state.activeZoneView = result.zoneView;
        state.activeSheet = result.zoneView.sheet;
      }
      state.activeSlot = '';
      state.activeDepth = 0;
      var panel = $('detailPanel');
      if (panel) { panel.classList.add('hidden'); panel.classList.remove('move-active'); }
      var bd = $('detailBackdrop');
      if (bd) bd.classList.add('hidden');
      document.body.style.overflow = '';
      renderOverviewTable();
      setStatus('已存檔 ' + moves.length + ' 筆移動 ✓', 'ok');
    } catch (e) {
      var msg = (e && e.message) ? e.message : String(e);
      setStatus('批次存檔失敗：' + msg, 'err');
      alert('批次存檔失敗：' + msg + '\n暫存仍保留，可重試或丟棄。');
    } finally {
      state.saving = false;
      hideGridLoading();
    }
  }

  function discardPendingMoves() {
    if (!state.pendingMoves.length) return;
    if (!confirm('丟棄 ' + state.pendingMoves.length + ' 筆尚未存檔的移動？畫面將重新載入。')) return;
    state.pendingMoves = [];
    renderPendingSaveBar_();
    document.body.classList.remove('has-pending-save');
    if (state.activeSheet) loadZone(state.activeSheet);
  }


  
  function openMoveConfirm(destSlot, destDepth, destLevel) {
    state.movePending = { destSlot: destSlot, destDepth: destDepth, destLevel: destLevel };
    executeMove();
  }

  function closeMoveConfirm() {
    $('moveConfirmOverlay').classList.add('hidden');
    state.movePending = null;
    
    var btn = $('moveConfirmBtn');
    if (btn) {
      btn.disabled = false;
      btn.textContent = '確認移動';
      btn.classList.remove('btn-loading', 'btn-retry');
    }
    var errMsg = document.querySelector('.move-err-msg');
    if (errMsg) errMsg.remove();
  }

  async function executeMove() {
    if (state.saving)      { return; }
    if (!state.movePending){ return; }
    if (!state.movingRow)  { return; }
    
    if (!state.movePending.destSlot || Number(state.movePending.destDepth) < 1) {
      setStatus('⚠️ 目標位置無效（排次=' + state.movePending.destDepth + '），請重新選擇', 'err');
      closeMoveConfirm();
      return;
    }

    
    var btn = $('moveConfirmBtn');
    var cancelBtn = btn && btn.parentNode && btn.parentNode.querySelector('.ghost-btn');
    if (btn) { btn.disabled = true; btn.textContent = '寫入中…'; btn.classList.add('btn-loading'); }
    if (cancelBtn) cancelBtn.disabled = true;
    var arrowEl = document.querySelector('#moveConfirmOverlay .move-arrow');
    if (arrowEl) arrowEl.classList.add('animating');

    var p = state.movePending;
    var src = state.movingRow;
    var destSheet = state.moveDestSheet || state.activeSheet;
    
    var snapKey = state.movingKey;
    var snapGroupKeys = (state.movingGroupKeys || []).slice();
    var isGroupMove = snapGroupKeys.length > 1;
    markWriteTime_(src.Sheet);
    markWriteTime_(destSheet);
    markWriteTime_(state.activeSheet);
    state.saving = true;
    setStatus('正在寫入試算表…', 'loading');
    showGridLoading('正在移動棧板並寫回試算表...');
    
    (function optimisticJump_() {
      try {
        document.querySelectorAll('.move-bar').forEach(function(el){ el.remove(); });
        document.body.classList.remove('has-move-bar');
        state.movingKey = '';
        state.movingRow = null;
        state.movingGroupId = '';
        state.movingGroupKeys = [];
        state.moveDestSlot = '';
        state.moveDestDepth = 0;
        state.moveDestSheet = '';
        state.moveDestZoneView = null;
        _destroyGhost();
        state.activeSlot = '';
        state.activeDepth = 0;
        var panel = $('detailPanel');
        if (panel) { panel.classList.add('hidden'); panel.classList.remove('move-active', 'show-edit-card'); }
        var bd = $('detailBackdrop');
        if (bd) bd.classList.add('hidden');
        document.body.style.overflow = '';
        renderOverviewTable();
      } catch (eOpt) { console.warn('optimisticJump', eOpt); }
    })();

    try {
      var operator = getOperator();
      var result = await gas(isGroupMove ? 'movePalletGroup' : 'movePallet',
        isGroupMove ? {
          groupKeys:   snapGroupKeys,
          sourceSheet: src.Sheet,
          destSheet:   destSheet,
          destSlot:    p.destSlot,
          destDepth:   p.destDepth,
          destLevel:   p.destLevel,
          operator:    operator
        } : {
          palletKey:   snapKey,
          sourceSheet: src.Sheet,
          destSheet:   destSheet,
          destSlot:    p.destSlot,
          destDepth:   p.destDepth,
          destLevel:   p.destLevel,
          operator:    operator
        });

      
      markWriteTime_(src.Sheet);
      markWriteTime_(destSheet);
      markWriteTime_(state.activeSheet);
      var destSheetLabel = destSheet;
      
      $('moveConfirmOverlay').classList.add('hidden');
      state.movePending = null;
      try { closeEdit(); } catch (eClose) {}
      
      if (btn) { btn.disabled = false; btn.textContent = '確認移動'; btn.classList.remove('btn-loading', 'btn-retry'); }
      
      state.movingKey   = '';
      state.movingRow   = null;
      state.movingGroupId   = '';
      state.movingGroupKeys = [];
      state.moveDestSlot  = '';
      state.moveDestDepth = 0;
      state.moveDestSheet = '';
      state.moveDestZoneView = null;
      _destroyGhost();
      closeMoveSlotPicker();
      
      if (result.history) applyHistory_(result.history);
      if (result.sourceZoneView) {
        cacheSet('zone_' + result.sourceZoneView.sheet, result.sourceZoneView);
      }
      if (result.destZoneView) {
        cacheSet('zone_' + result.destZoneView.sheet, result.destZoneView);
      }
      var zv = result.zoneView || null;
      if (!zv && result.destZoneView && result.destZoneView.sheet === destSheetLabel) zv = result.destZoneView;
      if (!zv) zv = result.sourceZoneView || (result.slots ? result : null);
      
      var refreshSheet = (destSheetLabel === src.Sheet) ? src.Sheet : destSheetLabel;
      if (zv && zv.sheet) {
        cacheSet('zone_' + zv.sheet, zv);
        state.activeZoneView = zv;
        state.activeSheet = zv.sheet;
      }
      
      setTimeout(function() {
        gas('getWarehouseZoneView', refreshSheet).then(function(fresh) {
          if (!fresh || !fresh.sheet) return;
          cacheSet('zone_' + fresh.sheet, fresh);
          if (state.activeSheet === fresh.sheet && !state.movingKey && !state.saving) {
            state.activeZoneView = fresh;
            renderOverviewTable();
            if (state.activeSlot) renderDetailPanel();
          }
        }).catch(function(){});
      }, 50);
      cacheRemove('search');
      var movedKey = [destSheetLabel, p.destSlot, p.destDepth, p.destLevel, src.SKU, src.Batch].join('||');
      state.recentlyMovedKey = movedKey;
      if (state._recentlyMovedTimer) clearTimeout(state._recentlyMovedTimer);
      state._recentlyMovedTimer = setTimeout(function() {
        state.recentlyMovedKey = '';
        renderOverviewTable();
      }, 10000);

            
      document.querySelectorAll('.move-bar').forEach(function(el){ el.remove(); });
      document.body.classList.remove('has-move-bar');
      state.activeSlot = '';
      state.activeDepth = 0;
      state.activePalletKey = '';
      state.activeItemKey = '';
      var panelOk = $('detailPanel');
      if (panelOk) {
        panelOk.classList.add('hidden');
        panelOk.classList.remove('show-edit-card', 'move-active');
      }
      var bdOk = $('detailBackdrop');
      if (bdOk) bdOk.classList.add('hidden');
      document.body.style.overflow = '';
      state._suppressFocus = true;
      renderOverviewTable();
      restoreViewScroll_();
      setTimeout(function() {
        restoreViewScroll_();
        state._suppressFocus = false;
      }, 50);
      setStatus('移動完成 ✓ → ' + (destSheetLabel !== src.Sheet ? esc(destSheetLabel) + ' ' : '') + esc(p.destSlot) + '列 ' + depthLabel(p.destDepth) + '（已回俯視圖）', 'ok');

    } catch (err) {
      
      if (btn) { btn.disabled = false; btn.textContent = '重試'; btn.classList.remove('btn-loading'); btn.classList.add('btn-retry'); }
      if (cancelBtn) cancelBtn.disabled = false;
      var msg = err && err.message ? err.message : String(err);
      var body = $('moveConfirmBody');
      if (body) body.insertAdjacentHTML('beforeend', '<div class="move-err-msg">⚠️ ' + esc(msg) + '</div>');
      setStatus('移動失敗：' + msg, 'err');
    } finally {
      state.saving = false;
      hideGridLoading();
    }
  }
  
  var _history = { canUndo: false, canRedo: false, undoLabel: '', redoLabel: '' };

  function applyHistory_(h) {
    if (!h) return;
    _history = h;
    renderUndoRedo();
  }

  var _historyBusy = ''; 

  function _undoRedoBtnHtml_(kind, cls) {
    var u = _history;
    var isUndo = (kind === 'undo');
    var enabled = isUndo ? u.canUndo : u.canRedo;
    var label = isUndo ? '還原' : '重做';
    var count = isUndo ? (u.undoCount || 0) : (u.redoCount || 0);
    var title = isUndo ? u.undoLabel : u.redoLabel;
    var busy = (_historyBusy === kind);
    var icon = busy ? '<span class="btn-icon">↻</span> ' : '';
    var badge = (enabled && count > 0) ? '<span class="step-count">' + count + '</span>' : '';
    return '<button class="' + cls + (!enabled ? ' disabled' : '') + (busy ? ' busy' : '') +
      '" onclick="do' + (isUndo ? 'Undo' : 'Redo') + '()" title="' + esc(title) + '" ' +
      (!enabled || busy ? 'disabled' : '') + '>' + icon + label + badge + '</button>';
  }

  function renderUndoRedo() {
    var wrap = $('undoRedoWrap');
    if (!wrap) return;
    wrap.innerHTML = _undoRedoBtnHtml_('undo', 'undo-btn') + _undoRedoBtnHtml_('redo', 'redo-btn');
  }

  async function doUndo() {
    if (state.saving) {
      setStatus('尚有寫入進行中，請稍候再還原', 'err');
      return;
    }
    if (!_history.canUndo) {
      setStatus('目前沒有可還原的移動', 'err');
      return;
    }
    state.saving = true;
    _historyBusy = 'undo';
    renderUndoRedo();
    
    document.querySelectorAll('.move-bar-undo').forEach(function(b){ b.disabled = true; });
    setStatus('還原中…', 'loading');
    showGridLoading('正在還原移動...');
    try {
      var result = await gas('undoLastMove');
      await applyMoveResult_(result);
      setStatus('已還原 ✓', 'ok');
    } catch (e) {
      var msg = (e && e.message) ? e.message : String(e || 'unknown');
      console.error('[doUndo]', msg, e);
      if (msg.indexOf('pallet not found') >= 0 || msg.indexOf('please refresh') >= 0) {
        setStatus('⚠️ 還原失敗：找不到原棧板，請重新整理後手動確認', 'err');
        _bgRefreshZone(state.activeSheet, false);
      } else {
        setStatus('還原失敗：' + msg, 'err');
        alert('還原失敗：' + msg);
      }
      gas('getMoveHistory').then(applyHistory_).catch(function(){});
    } finally {
      state.saving = false;
      _historyBusy = '';
      hideGridLoading();
      renderUndoRedo();
      if (state.activeSlot) renderDetailPanel();
    }
  }

  async function doRedo() {
    if (!_history.canRedo || state.saving) return;
    state.saving = true;
    _historyBusy = 'redo';
    renderUndoRedo();
    setStatus('重做中…', 'loading');
    showGridLoading('正在重做移動...');
    try {
      var result = await gas('redoLastMove');
      await applyMoveResult_(result);
      setStatus('已重做 ✓', 'ok');
    } catch (e) {
      var msg = (e.message || String(e));
      if (msg.indexOf('pallet not found') >= 0 || msg.indexOf('please refresh') >= 0) {
        setStatus('⚠️ 重做失敗：棧板位置已變動，請重新整理後手動確認', 'err');
        _bgRefreshZone(state.activeSheet, false);
      } else {
        setStatus('重做失敗：' + msg, 'err');
      }
      gas('getMoveHistory').then(applyHistory_).catch(function(){});
    } finally {
      state.saving = false;
      _historyBusy = '';
      hideGridLoading();
      renderUndoRedo();
    }
  }

  
  async function applyMoveResult_(result) {
    document.querySelectorAll('.move-bar').forEach(function(el){ el.remove(); });
    document.body.classList.remove('has-move-bar');
    state.movingKey = '';
    state.movingRow = null;
    state.movingGroupKeys = [];
    if (result && result.history) applyHistory_(result.history);
    if (result && result.sourceZoneView) {
      markWriteTime_(result.sourceZoneView.sheet);
      cacheSet('zone_' + result.sourceZoneView.sheet, result.sourceZoneView);
    }
    var zv = result ? (result.destZoneView || result.zoneView || result.sourceZoneView) : null;
    if (zv) {
      markWriteTime_(zv.sheet);
      cacheSet('zone_' + zv.sheet, zv);
      state.activeZoneView = zv;
      if (zv.sheet) state.activeSheet = zv.sheet;
    }
    var nav = result && result.navigateTo ? result.navigateTo : null;
    if (nav && nav.sheet && nav.sheet !== state.activeSheet) {
      
      try {
        var freshNav = await gas('getWarehouseZoneView', nav.sheet);
        cacheSet('zone_' + freshNav.sheet, freshNav);
        state.activeZoneView = freshNav;
        state.activeSheet = freshNav.sheet;
      } catch (e) { console.warn('applyMoveResult nav refresh', e); }
    } else if (!zv) {
      try {
        var sheet = (nav && nav.sheet) || state.activeSheet;
        if (sheet) {
          var fresh = await gas('getWarehouseZoneView', sheet);
          cacheSet('zone_' + fresh.sheet, fresh);
          state.activeZoneView = fresh;
          state.activeSheet = fresh.sheet;
        }
      } catch (e2) { console.warn('applyMoveResult refresh', e2); }
    }
    
    if (nav && nav.slot) {
      state.activeSlot = String(nav.slot);
      state.activeDepth = Number(nav.depth) || 0;
      state.activePalletKey = '';
      state.activeItemKey = '';
      if (isMobile()) document.body.style.overflow = 'hidden';
      state._suppressFocus = true;
      renderOverviewTable();
      renderDetailPanel();
      setTimeout(function(){ state._suppressFocus = false; }, 80);
    } else {
      state.activeSlot = '';
      state.activeDepth = 0;
      var panel = $('detailPanel');
      if (panel) {
        panel.classList.add('hidden');
        panel.classList.remove('show-edit-card', 'move-active');
      }
      var backdrop = $('detailBackdrop');
      if (backdrop) backdrop.classList.add('hidden');
      document.body.style.overflow = '';
      state._suppressFocus = true;
      renderOverviewTable();
      restoreViewScroll_();
      setTimeout(function() {
        restoreViewScroll_();
        state._suppressFocus = false;
      }, 80);
    }
    
    var bgSheet = state.activeSheet;
    if (bgSheet) {
      setTimeout(function() {
        gas('getWarehouseZoneView', bgSheet).then(function(fresh) {
          if (!fresh || state.saving || state.movingKey) return;
          cacheSet('zone_' + fresh.sheet, fresh);
          if (state.activeSheet === fresh.sheet) {
            state.activeZoneView = fresh;
            renderOverviewTable();
            if (state.activeSlot) renderDetailPanel();
          }
        }).catch(function(){});
      }, 80);
    }
  }
  

  

  function renderWarehouseMap() {
    try {
      var wrap = document.getElementById('warehouseMapWrap');
      if (!wrap) return;
      var sheet = state.activeSheet || '';
      var m = sheet.match(/^([A-C])-([A-H])區$/);
      if (!m) { wrap.innerHTML = ''; return; }
      var wh = m[1], activeZone = m[2];
      var layout = ZONE_LAYOUTS[wh];
      if (!layout) { wrap.innerHTML = ''; return; }
      var slotNum = parseInt(state.activeSlot, 10) || 0;
      var vw = layout.vw, vh = layout.vh;
      var zones = layout.zones, extras = layout.extras || [];
      var p = [];
      p.push('<rect width="' + vw + '" height="' + vh + '" fill="#0d1929" rx="5"/>');
      var i, e, lx, ly, rot, zid, z, isActive, fill, stroke, sw, fs, fc, pos, tx, anc;
      for (i = 0; i < extras.length; i++) {
        e = extras[i];
        p.push('<rect x="' + e.x + '" y="' + e.y + '" width="' + e.w + '" height="' + e.h + '" rx="2" fill="#0a1520"/>');
        if (e.label) {
          lx = e.x + e.w/2; ly = e.y + e.h/2;
          rot = e.rot ? ' transform="rotate(-90 ' + lx + ' ' + ly + ')"' : '';
          p.push('<text x="' + lx + '" y="' + (ly+4) + '" text-anchor="middle" font-size="7" fill="#4a6080" font-weight="800" font-family="system-ui"' + rot + '>' + e.label + '</text>');
        }
      }
      var zoneKeys = Object.keys(zones);
      for (i = 0; i < zoneKeys.length; i++) {
        zid = zoneKeys[i]; z = zones[zid];
        isActive = zid === activeZone;
        fill   = isActive ? 'rgba(73,209,125,0.22)' : 'rgba(255,255,255,0.07)';
        stroke = isActive ? '#49d17d' : 'rgba(255,255,255,0.2)';
        sw = isActive ? 2 : 1;
        p.push('<rect x="' + z.x + '" y="' + z.y + '" width="' + z.w + '" height="' + z.h + '" rx="3" fill="' + fill + '" stroke="' + stroke + '" stroke-width="' + sw + '"/>');
        lx = z.x + z.w/2; ly = z.y + z.h/2;
        var shortSide = Math.min(z.w, z.h);
        fs = shortSide < 20 ? 7 : shortSide < 30 ? 9 : 11;
        fc = isActive ? '#6eeaa0' : '#6080a0';
        if (z.h > z.w * 2.2) {
          p.push('<text x="' + lx + '" y="' + (ly+4) + '" text-anchor="middle" font-size="' + fs + '" font-weight="900" fill="' + fc + '" font-family="system-ui" transform="rotate(-90 ' + lx + ' ' + ly + ')">' + zid + '</text>');
        } else {
          p.push('<text x="' + lx + '" y="' + (ly+4) + '" text-anchor="middle" font-size="' + fs + '" font-weight="900" fill="' + fc + '" font-family="system-ui">' + zid + '</text>');
          if (isActive && shortSide >= 24) {
            p.push('<text x="' + lx + '" y="' + (ly+13) + '" text-anchor="middle" font-size="6" font-weight="700" fill="rgba(110,234,160,0.7)" font-family="system-ui">' + (DIR_ARROW[z.dir] || '') + '</text>');
          }
        }
      }
      if (slotNum > 0 && zones[activeZone]) {
        pos = getMarkerXY(zones[activeZone], slotNum);
        p.push('<circle cx="' + pos.mx + '" cy="' + pos.my + '" r="10" fill="rgba(255,60,60,0.22)"/>');
        p.push('<circle cx="' + pos.mx + '" cy="' + pos.my + '" r="6" fill="rgba(255,60,60,0.65)"/>');
        p.push('<circle cx="' + pos.mx + '" cy="' + pos.my + '" r="3.5" fill="#ff3333"/>');
        tx = pos.mx > vw/2 ? pos.mx - 11 : pos.mx + 11;
        anc = pos.mx > vw/2 ? 'end' : 'start';
        p.push('<text x="' + tx + '" y="' + (pos.my+4) + '" text-anchor="' + anc + '" font-size="9" font-weight="900" fill="#ffaaaa" font-family="system-ui">' + slotNum + '</text>');
      }
      p.push('<text x="' + (vw-4) + '" y="' + (vh-4) + '" text-anchor="end" font-size="8" fill="#253545" font-weight="900" font-family="system-ui">' + wh + '</text>');
      wrap.innerHTML = '<svg viewBox="0 0 ' + vw + ' ' + vh + '" width="100%" style="display:block" xmlns="http://www.w3.org/2000/svg">' + p.join('') + '</svg>';
    } catch(e2) {   }
  }

  function renderMinimapSvg() {
    try {
      var wrap = document.getElementById('minimapSvg');
      var wrapOuter = document.getElementById('minimapWrap');
      if (!wrap) return;

      const zoneView = state.activeZoneView;
      if (!zoneView || !zoneView.slots || !zoneView.slots.length) {
        if (wrapOuter) wrapOuter.style.display = 'none';
        return;
      }
      if (wrapOuter) wrapOuter.style.display = 'block';

      var sheet = state.activeSheet || '';
      var m = sheet.match(/^([A-C])-([A-H])區$/);
      var wh = m ? m[1] : 'B', activeZone = m ? m[2] : 'G';
      var layout = ZONE_LAYOUTS[wh] || ZONE_LAYOUTS['B'];
      if (!layout) return;

      var slotNum = parseInt(state.activeSlot, 10) || 1;
      var vw = layout.vw, vh = layout.vh;
      var zones = layout.zones;
      var p = [];
      p.push('<rect width="' + vw + '" height="' + vh + '" fill="#08111e" rx="4"/>');

      Object.keys(zones).forEach(function(zid) {
        var z = zones[zid];
        var isActive = zid === activeZone;
        var fill = isActive ? 'rgba(73,209,125,0.28)' : 'rgba(255,255,255,0.07)';
        var stroke = isActive ? '#49d17d' : 'rgba(255,255,255,0.18)';
        var sw = isActive ? 1.5 : 0.8;
        p.push('<rect x="' + z.x + '" y="' + z.y + '" width="' + z.w + '" height="' + z.h + '" rx="2" fill="' + fill + '" stroke="' + stroke + '" stroke-width="' + sw + '"/>');
        p.push('<text x="' + (z.x + z.w/2) + '" y="' + (z.y + z.h/2 + 3) + '" text-anchor="middle" font-size="8" font-weight="900" fill="' + (isActive ? '#7ee787' : '#506880') + '" font-family="system-ui">' + zid + '</text>');
      });

      if (zones[activeZone]) {
        var pos = getMarkerXY(zones[activeZone], slotNum);
        p.push('<circle cx="' + pos.mx + '" cy="' + pos.my + '" r="7" fill="rgba(255,50,50,0.3)"/>');
        p.push('<circle cx="' + pos.mx + '" cy="' + pos.my + '" r="4" fill="#ff3333" stroke="#ffffff" stroke-width="1.2"/>');
      }

      wrap.innerHTML = '<svg viewBox="0 0 ' + vw + ' ' + vh + '" width="100%" height="100%" style="display:block;cursor:pointer" onclick="onMinimapClick(event)">' + p.join('') + '</svg>';
    } catch(e) {}
  }

  function onMinimapClick(e) {
    try {
      var sheet = state.activeSheet || '';
      var m = sheet.match(/^([A-C])-([A-H])區$/);
      if (!m) return;
      var wh = m[1];
      var layout = ZONE_LAYOUTS[wh];
      if (!layout) return;
      var rect = e.currentTarget.getBoundingClientRect();
      var clickX = ((e.clientX - rect.left) / rect.width) * layout.vw;
      var clickY = ((e.clientY - rect.top) / rect.height) * layout.vh;

      Object.keys(layout.zones).forEach(function(zid) {
        var z = layout.zones[zid];
        if (clickX >= z.x && clickX <= z.x + z.w && clickY >= z.y && clickY <= z.y + z.h) {
          var targetSheet = wh + '-' + zid + '區';
          if (targetSheet !== state.activeSheet) {
            loadZone(targetSheet);
          }
        }
      });
    } catch(err) {}
  }

  const isMobile = () => window.matchMedia("(max-width: 720px)").matches;

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }

  function showGridLoading(text) {
    const overlay = $("gridLoadingOverlay");
    const txt = $("gridLoadingText");
    if (txt && text) txt.textContent = text;
    if (overlay) {
      
      if (overlay.parentElement !== document.body) {
        document.body.appendChild(overlay);
      }
      overlay.classList.remove("hidden");
      overlay.style.display = 'flex';
      overlay.style.visibility = 'visible';
      overlay.style.pointerEvents = 'all';
      overlay.style.position = 'fixed';
      overlay.style.inset = '0';
      overlay.style.zIndex = '10050';
    }
  }

  function hideGridLoading() {
    const overlay = $("gridLoadingOverlay");
    if (overlay) {
      overlay.classList.add("hidden");
      overlay.style.display = 'none';
      overlay.style.visibility = 'hidden';
      overlay.style.pointerEvents = 'none';
    }
  }

  let _statusTimer = null;
  function setStatus(msg, cls) {
    const el = $("cacheInfo");
    const btn = document.querySelector(".cache-refresh");
    if (!el) return;
    clearTimeout(_statusTimer);
    el.textContent = msg;
    const isLoading = cls === 'loading' || (!cls && msg && (msg.includes('...') || msg.includes('…') || msg.includes('載入') || msg.includes('讀取') || msg.includes('同步') || msg.includes('連線') || msg.includes('寫回') || msg.includes('移動') || msg.includes('更新') || msg.includes('還原') || msg.includes('重做')));
    
    el.className = 'cache-info ' + (cls || (isLoading ? 'loading' : ''));

    if (btn) {
      if (isLoading) {
        btn.classList.add('spinning');
      } else {
        btn.classList.remove('spinning');
      }
    }

    if (cls === 'ok') {
      _statusTimer = setTimeout(() => { el.classList.add('settled'); }, 3000);
    }
  }

  function cacheTime(key) {
    try {
      const raw = localStorage.getItem('wms_' + key);
      if (!raw) return null;
      const t = JSON.parse(raw).t;
      if (!t) return null;
      const date = new Date(t);
      const hh = String(date.getHours()).padStart(2,'0');
      const mm = String(date.getMinutes()).padStart(2,'0');
      return hh + ':' + mm + '更新';
    } catch (e) { return null; }
  }

  function fail(err) {
    hideGridLoading();
    const msg = (err && (err.stack || err.message)) || String(err);
    setStatus("載入失敗：\n" + msg, "bad");
  }

  function gas(method, ...args) {
    return new Promise((resolve, reject) => {
      if (typeof google === "undefined" || !google.script || !google.script.run) {
        reject(new Error("google.script.run 不存在，請確認從 Apps Script /exec 開啟"));
        return;
      }
      let done = false;
      const timeoutMs = method === 'movePalletGroup' ? 90000 : method === 'movePallet' ? 60000 : method === "updateWarehousePallet" ? 45000 : method === "getSearchIndex" ? 120000 : 60000;
      console.log('[gas calling]', method, JSON.stringify(args[0] || ''));
      const timer = setTimeout(() => {
        if (!done) {
          done = true;
          console.error('[gas TIMEOUT]', method, timeoutMs + 'ms');
          reject(new Error(method + " timeout after " + Math.round(timeoutMs / 1000) + "s"));
        }
      }, timeoutMs);
      try {
        google.script.run
          .withSuccessHandler(result => { console.log('[gas raw OK]', method); if (done) return; done = true; clearTimeout(timer); console.log('[gas OK]', method, result); resolve(result); })
          .withFailureHandler(error => {
            var msg = (error && (error.message || error.details || error.name)) || String(error || 'unknown');
            console.error('[gas raw ERR]', method, msg, error);
            if (done) return; done = true; clearTimeout(timer);
            console.error('[gas ERR]', method, msg);
            reject(new Error(msg));
          })[method](...args);
        console.log('[gas queued]', method);
      } catch(syncErr) {
        done = true; clearTimeout(timer);
        console.error('[gas SYNC-THROW]', method, syncErr);
        reject(syncErr);
      }
    });
  }

  

  function formatPalletQty_(row) {
    var box = Number(row && row.BoxQty != null ? row.BoxQty : 0) || 0;
    var piece = Number(row && row.PieceQty != null ? row.PieceQty : 0) || 0;
    if (box > 0 && piece > 0) return box + '箱/' + piece + '片';
    if (piece > 0 && box <= 0) return piece + '片';
    return box + '箱';
  }

  function qtyStatusHtml(fontColor) {
    if (fontColor === 'RED')    return '<span class="qty-status reported">已回報</span>';
    if (fontColor === 'GREEN')  return '<span class="qty-status pending">待重點</span>';
    if (fontColor === 'YELLOW') return '<span class="qty-status nosys">無庫存</span>';
    return '';
  }

  function paletteClass(row) {
    const bg = String(row.BgColor || "WHITE").toLowerCase();
    const font = String(row.FontColor || "BLACK").toLowerCase();
    return [bg === "red" ? "red" : bg === "yellow" ? "yellow" : bg === "green" ? "green" : "white", font === "blue" ? "bluefont" : ""].join(" ").trim();
  }

  function rowText(row) {
    return [row.SKU, row.Batch, row.HanhwaCode, row.Brand, row.Series, row.OriginalName, row.Sheet, row.Stack, row.Slot].join(" ").toLowerCase();
  }

  function isRecentlyMoved(row) {
    if (!state.recentlyMovedKey || !row) return false;
    var k1 = String(state.recentlyMovedKey).trim().toLowerCase();
    var k2 = String(row.PalletKey || row.PalletID || '').trim().toLowerCase();
    if (k1 && k2 && k1 === k2) return true;

    var kp1 = k1.split('||');
    if (kp1.length >= 5) {
      var rowSheet = String(row.Sheet || state.activeSheet || '').trim().toLowerCase();
      var rowSlot  = String(row.Slot || '').trim().toLowerCase();
      var rowDepth = Number(row.Depth || 0);
      var rowSKU   = String(row.SKU || '').trim().toLowerCase();

      var keySheet = String(kp1[0] || '').trim().toLowerCase();
      var keySlot  = String(kp1[1] || '').trim().toLowerCase();
      var keyDepth = Number(kp1[2] || 0);
      var keySKU   = String(kp1[4] || '').trim().toLowerCase();

      if (rowSheet === keySheet && rowSlot === keySlot && rowDepth === keyDepth && rowSKU === keySKU) {
        return true;
      }
    }
    return false;
  }

  function formatMoveTime(isoStr) {
    if (!isoStr) return '-';
    try {
      var d = new Date(isoStr);
      if (isNaN(d.getTime())) return '-';
      var now = new Date();
      var isToday = (d.getFullYear() === now.getFullYear() &&
                     d.getMonth() === now.getMonth() &&
                     d.getDate() === now.getDate());

      var hh = String(d.getHours()).padStart(2, '0');
      var mm = String(d.getMinutes()).padStart(2, '0');
      var timeStr = hh + ':' + mm;

      if (isToday) {
        return timeStr;
      } else {
        var month = String(d.getMonth() + 1).padStart(2, '0');
        var day = String(d.getDate()).padStart(2, '0');
        return month + '/' + day + ' ' + timeStr;
      }
    } catch(e) {
      return String(isoStr);
    }
  }

  
  const CACHE_FRESH_MS  =  5 * 60 * 1000;   
  const CACHE_STALE_MS  = 30 * 60 * 1000;   
  

  function cacheGet(key) {
    try {
      const raw = localStorage.getItem('wms_' + key);
      if (!raw) return null;
      return JSON.parse(raw).v;
    } catch (e) { return null; }
  }
  function cacheSet(key, val) {
    var data = JSON.stringify({ t: Date.now(), v: val });
    try {
      localStorage.setItem('wms_' + key, data);
    } catch (e) {
      
      if (e.name === 'QuotaExceededError' || e.code === 22 || e.code === 1014) {
        try {
          var entries = [];
          for (var k in localStorage) {
            if (!String(k).startsWith('wms_zone_')) continue;
            try { entries.push({ k: k, t: JSON.parse(localStorage.getItem(k)).t || 0 }); } catch(e2) {}
          }
          entries.sort(function(a, b) { return a.t - b.t; }); 
          var toDel = Math.max(1, Math.ceil(entries.length / 2));
          for (var i = 0; i < toDel; i++) localStorage.removeItem(entries[i].k);
          localStorage.setItem('wms_' + key, data); 
        } catch(e3) { console.warn('[cacheSet] quota retry failed:', key, e3); }
      } else {
        console.warn('[cacheSet] failed:', key, e);
      }
    }
  }
  function cacheAgeMs(key) {
    try {
      const raw = localStorage.getItem('wms_' + key);
      if (!raw) return Infinity;
      const t = JSON.parse(raw).t;
      return t ? Date.now() - t : Infinity;
    } catch(e) { return Infinity; }
  }
  function cacheAge(key) {
    try {
      const raw = localStorage.getItem('wms_' + key);
      if (!raw) return null;
      const t = JSON.parse(raw).t;
      if (!t) return null;
      const mins = Math.round((Date.now() - t) / 60000);
      return mins < 60 ? mins + ' 分前' : Math.round(mins / 60) + ' 小時前';
    } catch (e) { return null; }
  }
  function cacheClear() {
    Object.keys(localStorage).filter(k => k.startsWith('wms_')).forEach(k => localStorage.removeItem(k));
  }

  
  
  var _bgRefreshingZones = {};
  var _lastWriteTime = {};   

  
  function markWriteTime_(sheetName) {
    _lastWriteTime[sheetName] = Date.now();
  }

  async function _bgRefreshZone(sheetName, isSilent) {
    if (_bgRefreshingZones[sheetName]) return;   
    _bgRefreshingZones[sheetName] = true;
    var startTime = Date.now();   
    try {
      if (!isSilent && state.activeSheet === sheetName) setStatus('同步中…', 'loading');
      const fresh = await gas('getWarehouseZoneView', sheetName);
      
      if ((_lastWriteTime[sheetName] || 0) > startTime) {
        console.log('[bgRefresh] discarded stale result for', sheetName);
        return;
      }
      cacheSet('zone_' + sheetName, fresh);
      if (state.activeSheet === sheetName) {
        
        state.activeZoneView = fresh;
        if (!state.editingRow && !state.movingKey) {
          renderOverviewTable();
          
          if (!$('moveConfirmOverlay') || $('moveConfirmOverlay').classList.contains('hidden')) {
            renderDetailPanel();
          }
        }
        if (!isSilent) setStatus('已同步 ' + (cacheTime('zone_' + sheetName) || ''), 'ok');
      }
      renderZoneChips();   
    } catch(e) {
      console.warn('[bgRefresh]', sheetName, e);
      if (!isSilent && state.activeSheet === sheetName) setStatus('背景同步失敗', 'bad');
    } finally {
      _bgRefreshingZones[sheetName] = false;
    }
  }

  
  var _preloadDone = false;
  async function _preloadAllZones() {
    if (_preloadDone) return;
    _preloadDone = true;
    const sheets = state.sheets || [];
    for (const sheet of sheets) {
      if (sheet.name === state.activeSheet) continue;    
      const ageMs = cacheAgeMs('zone_' + sheet.name);
      if (ageMs < CACHE_STALE_MS) continue;              
      await _bgRefreshZone(sheet.name, true);            
      await new Promise(r => setTimeout(r, 600));        
    }
    console.log('[preload] all zones warmed');
  }

  async function boot() {
    try {
      showGridLoading("連線中，讀取區域清單...");
      initOperator();
      const d = new Date();
      const ver = 'V' + String(d.getMonth()+1).padStart(2,'0') + String(d.getDate()).padStart(2,'0');
      if ($("ver")) $("ver").textContent = ver;

      let sheets = cacheGet('sheets');
      if (sheets) {
        state.sheets = sheets;
        setStatus("讀取區域資料…", "loading");
      } else {
        setStatus("讀取區域清單...", "loading");
        sheets = await gas("getInventorySheetList");
        state.sheets = sheets;
        cacheSet('sheets', sheets);
      }

      renderZoneChips();
      const lastZone = localStorage.getItem('wms_last_zone');
      const preferred = (lastZone && state.sheets.find(s => s.name === lastZone))
        || state.sheets.find(s => s.name === "B-G區") || state.sheets[0];
      if (!preferred) throw new Error("沒有可用分區");
      await loadZone(preferred.name);
      preloadSearchIndex();
      
      gas('getMoveHistory').then(applyHistory_).catch(() => {});
      
      setTimeout(_preloadAllZones, 3000);
    } catch (err) {
      hideGridLoading();
      fail(err);
    }
  }

  function buildFallbackSearchIndex_() {
    var rows = [];
    var seen = {};
    function pushPallet(p, sheet) {
      if (!p) return;
      var key = p.PalletKey || [sheet, p.Slot, p.Depth, p.Level, p.SKU, p.Batch].join('||');
      if (seen[key]) return;
      seen[key] = true;
      rows.push({
        Sheet: sheet || p.Sheet || '',
        Slot: p.Slot,
        Depth: p.Depth,
        Level: p.Level,
        SKU: p.SKU || '',
        Batch: p.Batch || '',
        HanhwaCode: p.HanhwaCode || '',
        Brand: p.Brand || '',
        Company: p.Company || '',
        Branches: p.Branches || [],
        PalletKey: key,
        BgColor: p.BgColor || '',
        Status: p.Status || '',
        BoxQty: p.BoxQty,
        PieceQty: p.PieceQty
      });
    }
    function ingestZone(zv) {
      if (!zv) return;
      var sheet = zv.sheet || '';
      (zv.slots || []).forEach(function(slot) {
        (slot.pallets || []).forEach(function(p) { pushPallet(p, sheet); });
        (slot.depths || []).forEach(function(d) {
          (d.pallets || []).forEach(function(p) { pushPallet(p, sheet); });
        });
      });
    }
    ingestZone(state.activeZoneView);
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (!k || k.indexOf('wms_zone_') !== 0) continue;
        try {
          var wrap = JSON.parse(localStorage.getItem(k));
          ingestZone(wrap && wrap.v);
        } catch (e1) {}
      }
    } catch (e2) {}
    return rows;
  }

  async function preloadSearchIndex() {
    try {
      let rows = cacheGet('search');
      const ageMs = cacheAgeMs('search');
      if (!rows || ageMs >= CACHE_STALE_MS) {
        const raw = await gas("getSearchIndex");
        rows = typeof raw === 'string' ? JSON.parse(raw) : raw;
        if (Array.isArray(rows)) cacheSet('search', rows);
      }
      if (Array.isArray(rows)) {
        state.searchRows = rows;
        state.searchReady = true;
        renderSearch();
        return;
      }
      throw new Error('search index empty');
    } catch (err) {
      console.warn("search preload failed", err);
      var msg = (err && err.message) ? err.message : String(err || 'unknown');
      var fallback = buildFallbackSearchIndex_();
      state.searchRows = fallback;
      state.searchReady = true;
      if (fallback.length) {
        setStatus('搜尋索引載入失敗，已用已載入分區建立臨時索引（' + fallback.length + ' 筆）：' + msg, 'err');
      } else {
        setStatus('搜尋索引載入失敗：' + msg + '（尚無可用分區資料，請先打開分區後再搜）', 'err');
      }
      try { renderSearch(); } catch (e3) {}
    }
  }

  async function loadZone(sheetName, preferredSlot, preferredDepth, preferredPalletKey) {
    state.activeSheet = sheetName;
    localStorage.setItem('wms_last_zone', sheetName);
    renderZoneChips();

    const ageMs = cacheAgeMs('zone_' + sheetName);
    let zoneView = cacheGet('zone_' + sheetName);

    if (zoneView) {
      
      state.activeZoneView = zoneView;
      state.activeSlot = preferredSlot || "";
      state.activeDepth = Number(preferredDepth || 0);
      state.activePalletKey = preferredPalletKey || "";
      state.activeItemKey = preferredPalletKey || "";
      renderOverviewTable();
      renderDetailPanel();
      renderSearch();
      hideGridLoading();

      if (ageMs < CACHE_FRESH_MS) {
        setStatus('快取 ' + (cacheTime('zone_' + sheetName) || ''), 'ok');
      } else {
        
        _bgRefreshZone(sheetName, false);
      }
      return;   
    }

    
    showGridLoading("載入 " + sheetName + " 資料中...");
    setStatus("載入 " + sheetName + "...", "loading");
    try {
      zoneView = await gas("getWarehouseZoneView", sheetName);
      cacheSet('zone_' + sheetName, zoneView);
      const t = cacheTime('zone_' + sheetName);
      setStatus("已更新 " + (t || ''), "ok");

      state.activeZoneView = zoneView;
      state.activeSlot = preferredSlot || "";
      state.activeDepth = Number(preferredDepth || 0);
      state.activePalletKey = preferredPalletKey || "";
      state.activeItemKey = preferredPalletKey || "";
      renderOverviewTable();
      renderDetailPanel();
      renderSearch();
    } finally {
      hideGridLoading();
    }
  }

  async function forceRefresh() {
    showGridLoading("重新讀取倉儲資料...");
    setStatus("清除快取，重新讀取...", "loading");
    cacheClear();
    state.sheets = [];
    state.activeZoneView = null;
    state.searchRows = [];
    state.searchReady = false;
    await boot();
  }

  function selectWhTab(wh) {
    state.selectedWhTab = wh;
    document.querySelectorAll('.wh-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.wh === wh);
    });
    renderZoneChips();
  }

  function renderZoneChips() {
    const zoneHits = searchZoneSet();
    const zoneCompany = searchZoneCompanyMap();
    const q = currentSearchQuery();
    const whTab = state.selectedWhTab || 'ALL';

    var filteredSheets = state.sheets || [];
    if (whTab === 'A') {
      filteredSheets = filteredSheets.filter(s => s.name.startsWith('A-'));
    } else if (whTab === 'B') {
      filteredSheets = filteredSheets.filter(s => s.name.startsWith('B-'));
    } else if (whTab === 'C') {
      filteredSheets = filteredSheets.filter(s => s.name.startsWith('C-'));
    }

    const sorted = hasSearchQuery(q)
      ? [...filteredSheets].sort((a, b) => (zoneHits.has(a.name) ? 0 : 1) - (zoneHits.has(b.name) ? 0 : 1))
      : filteredSheets;

    const searching = hasSearchQuery(q);
    $("zoneChips").innerHTML = sorted.map(sheet => {
      const active = sheet.name === state.activeSheet ? "active" : "";
      const isHit = searching && zoneHits.has(sheet.name);
      
      const hit = isHit ? 'search-hit-frame' : '';
      const cc = isHit ? companyClass(zoneCompany[sheet.name]) : '';
      var syncDot = '';
      if (!searching) {
        const isSyncing = !!_bgRefreshingZones[sheet.name];
        const ageMs2 = cacheAgeMs('zone_' + sheet.name);
        const hasFreshCache = ageMs2 < CACHE_STALE_MS;
        
        syncDot = isSyncing
          ? '<i class="zone-sync-dot syncing" title="背景同步中"></i>'
          : (!hasFreshCache ? '<i class="zone-sync-dot stale" title="快取較舊（非搜尋標記）"></i>' : '');
      }
      return '<button class="zone-chip ' + active + ' ' + hit + ' ' + cc + '" data-sheet="' + esc(sheet.name) + '" onclick="loadZone(' + JSON.stringify(sheet.name) + '); return false;">' + esc(sheet.name) + syncDot + '</button>';
    }).join("");
  }

  function slotById(slotId) {
    const zoneView = state.activeZoneView || {};
    return (zoneView.slots || []).find(slot => slot.slotId === slotId) || null;
  }

  function depthDataOf(slot, depth) {
    return (slot && slot.depths || []).find(d => Number(d.depth) === Number(depth)) || null;
  }

  function sortedPallets(depthData) {
    return ((depthData && depthData.pallets) || []).slice().sort((a, b) => Number(a.Level || 0) - Number(b.Level || 0));
  }

  function currentSearchQuery() {
    var inputSku = ($("searchSku") && $("searchSku").value || "").trim().toLowerCase();
    var inputBatch = ($("searchBatch") && $("searchBatch").value || "").trim().toLowerCase();
    var pick = state.searchPick || { sku: '', batch: '' };
    return {
      sku: (pick.sku || inputSku || "").toLowerCase(),
      batch: (pick.batch || inputBatch || "").toLowerCase(),
      rawSku: inputSku,
      rawBatch: inputBatch,
      pickedSku: (pick.sku || "").toLowerCase(),
      pickedBatch: (pick.batch || "").toLowerCase()
    };
  }

  function hasSearchQuery(q) {
    return !!((q && (q.sku || q.rawSku)) || (q && (q.batch || q.rawBatch)));
  }

  function rowMatchesQuery(row, q) {
    if (!q) return false;
    var needle = (q.pickedSku || q.sku || q.rawSku || "").toLowerCase();
    var skuOk = true;
    if (needle) {
      var sku = String(row.SKU || "").toLowerCase();
      var han = String(row.HanhwaCode || "").toLowerCase();
      if (q.pickedSku) {
        
        skuOk = sku === q.pickedSku || han === q.pickedSku;
      } else if (/^\d{5}$/.test(needle)) {
        
        skuOk = han === needle || han.endsWith(needle) || sku.endsWith(needle) || sku.indexOf(needle) >= 0;
      } else {
        skuOk = sku === needle || sku.indexOf(needle) >= 0 || han === needle || han.indexOf(needle) >= 0 || rowText(row).includes(needle);
      }
    }
    var batchNeedle = (q.pickedBatch || q.batch || q.rawBatch || "").toLowerCase();
    var batchOk = !batchNeedle || String(row.Batch || "").toLowerCase().indexOf(batchNeedle) >= 0;
    
    if (q.pickedSku && !q.pickedBatch && !q.rawBatch) batchOk = true;
    return skuOk && batchOk;
  }

  function searchMatches() {
    const q = currentSearchQuery();
    if (!hasSearchQuery(q) || !state.searchReady) return [];
    return state.searchRows.filter(row => rowMatchesQuery(row, q));
  }

  function searchZoneSet() {
    return new Set(searchMatches().map(row => row.Sheet));
  }

  function searchSlotDepthSet() {
    return new Set(searchMatches().map(row => [row.Sheet, row.Slot, row.Depth].join('||')));
  }

  function currentDepthPallets() {
    const slot = slotById(state.activeSlot);
    const depthData = slot ? depthDataOf(slot, state.activeDepth) : null;
    return sortedPallets(depthData);
  }

  function detailValue(v) {
    if (v === null || v === undefined || v === '') return '-';
    return v;
  }

  function companyClass(company) {
    if (!company) return '';
    if (company.includes('安帝嘉')) return 'co-antiga'; 
    if (company.includes('喜悅納')) return 'co-xina';   
    if (company.includes('高雅瓷')) return 'co-koya';   
    if (company.includes('漢樺')) return 'co-hanhwa';   
    return '';
  }

  function companyForRow(row) {
    if (!row) return '';
    var branches = row.Branches || [];
    for (var i = 0; i < branches.length; i++) {
      var c = branches[i] && branches[i].Company;
      if (c && c !== '未知分公司') return c;
    }
    if (row.Company && row.Company !== '未知分公司') return row.Company;
    
    var han = String(row.HanhwaCode || '').trim();
    if (/^\d{5}$/.test(han)) return '漢樺';
    var sheet = String(row.Sheet || '');
    if (sheet.startsWith('B-')) return '高雅瓷'; 
    if (sheet.startsWith('A-') || sheet.startsWith('C-')) return '喜悅納';
    return '';
  }

  function searchZoneCompanyMap() {
    const q = currentSearchQuery();
    if (!hasSearchQuery(q) || !state.searchReady) return {};
    const map = {};
    searchMatches().forEach(row => {
      const sheet = row.Sheet;
      if (map[sheet]) return;
      map[sheet] = companyForRow(row);
    });
    return map;
  }

   
  function uniqueSkuCandidates_(needle) {
    needle = String(needle || '').trim().toLowerCase();
    if (!needle || !state.searchReady) return [];
    var map = {};
    state.searchRows.forEach(function(row) {
      var sku = String(row.SKU || '').trim();
      if (!sku) return;
      var skuL = sku.toLowerCase();
      var han = String(row.HanhwaCode || '').toLowerCase();
      var ok = false;
      if (/^\d{5}$/.test(needle)) {
        ok = han === needle || skuL.endsWith(needle) || skuL.indexOf(needle) >= 0;
      } else {
        ok = skuL === needle || skuL.indexOf(needle) >= 0 || han === needle;
      }
      if (!ok) return;
      if (!map[skuL]) {
        map[skuL] = { sku: sku, company: companyForRow(row), count: 0 };
      }
      map[skuL].count += 1;
      
      if (!map[skuL].company) map[skuL].company = companyForRow(row);
    });
    return Object.keys(map).map(function(k){ return map[k]; })
      .sort(function(a,b){ return a.sku.localeCompare(b.sku); });
  }

  function batchesForSku_(sku) {
    sku = String(sku || '').trim().toLowerCase();
    if (!sku) return [];
    var set = {};
    state.searchRows.forEach(function(row) {
      if (String(row.SKU || '').toLowerCase() !== sku) return;
      var b = String(row.Batch || '').trim();
      if (b) set[b] = (set[b] || 0) + 1;
    });
    return Object.keys(set).sort().map(function(b){ return { batch: b, count: set[b] }; });
  }

  function selectSearchSku(sku) {
    state.searchPick = state.searchPick || { sku: '', batch: '' };
    state.searchPick.sku = sku || '';
    state.searchPick.batch = '';
    if ($("searchBatch")) $("searchBatch").value = '';
    renderSearch();
    
    navigateToFirstSearchHit_();
  }

  function selectSearchBatch(batch) {
    state.searchPick = state.searchPick || { sku: '', batch: '' };
    state.searchPick.batch = batch || '';
    if ($("searchBatch")) $("searchBatch").value = batch || '';
    renderSearch();
    navigateToFirstSearchHit_();
  }

  function clearSearchPick() {
    state.searchPick = { sku: '', batch: '' };
    renderSearch();
  }

  async function navigateToFirstSearchHit_() {
    var matches = searchMatches();
    if (!matches.length) return;
    
    var hit = matches.find(function(r){ return r.Sheet === state.activeSheet; }) || matches[0];
    if (!hit) return;
    try {
      if (hit.Sheet !== state.activeSheet) {
        await loadZone(hit.Sheet, hit.Slot, hit.Depth, hit.PalletKey);
      } else {
        
        state.activeSlot = '';
        state.activeDepth = 0;
        renderOverviewTable();
        setTimeout(function() {
          scrollSearchHitIntoView_(hit.Slot, hit.Depth);
        }, 80);
      }
    } catch (e) { console.warn('navigate search', e); }
  }

  function scrollSearchHitIntoView_(slotId, depth) {
    var wrap = $("overviewTableWrap");
    if (!wrap) return;
    var btn = wrap.querySelector('.cell-btn[data-slot="' + String(slotId).replace(/"/g,'') + '"][data-depth="' + String(depth) + '"]');
    if (!btn) {
      
      var all = wrap.querySelectorAll('.cell-btn.hit, .cell-btn.pulse');
      if (all.length) btn = all[0];
    }
    if (!btn) return;
    try {
      btn.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
    } catch (e) {
      btn.scrollIntoView(true);
    }
  }

  function locationCode(row) {
    const area = (row.Sheet || '').replace(/-/g, '_');
    const slot = row.Slot || '-';
    const depth = row.Depth || 0;
    const level = row.Level || '-';
    return area + '_' + slot + '列_' + depth + '排_' + level + '層';
  }

  function driveThumbUrl(url) {
    if (!url) return '';
    const m = String(url).match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    if (!m) return '';
    return 'https://drive.google.com/thumbnail?id=' + m[1] + '&sz=w400';
  }

  function toggleItemSpecs() {
    const specs = $("itemSpecs");
    const btn = $("itemDetailToggle");
    if (!specs) return;
    const nowHidden = specs.classList.toggle("hidden");
    if (btn) btn.textContent = nowHidden ? "查看完整資訊 ▼" : "收起 ▲";
  }


  
  state.crossColMin = state.crossColMin || 132;
  function applyCrossZoom() {
    var grid = document.querySelector('.cross-grid');
    if (!grid) return;
    grid.style.setProperty('--cross-col-min', state.crossColMin + 'px');
  }
  function crossZoomIn() {
    state.crossColMin = Math.min(200, (state.crossColMin || 132) + 16);
    applyCrossZoom();
  }
  function crossZoomOut() {
    state.crossColMin = Math.max(88, (state.crossColMin || 132) - 16);
    applyCrossZoom();
  }

  function zoomIn() {
    state.zoomScale = Math.min(+(state.zoomScale + 0.2).toFixed(1), 3.0);
    applyZoom();
  }
  function zoomOut() {
    state.zoomScale = Math.max(+(state.zoomScale - 0.2).toFixed(1), 0.4);
    applyZoom();
  }
  function applyZoom() {
    const table = $("overviewTableWrap") && $("overviewTableWrap").querySelector('.overview-table');
    if (table) table.style.zoom = state.zoomScale;
  }

  function scrollActiveCellIntoView() {
    const wrap = $("overviewTableWrap");
    if (!wrap) return;
    const active = wrap.querySelector('.cell-btn.active');
    if (!active) return;
    active.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
  }

  function scrollActiveItemIntoView() {
    const active = $("cellItems") ? $("cellItems").querySelector('.item-chip.active') : null;
    if (!active) return;
    active.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
  }

  function focusSearchTarget() {
    if (state._suppressFocus) return;
    setTimeout(() => {
      if (state._suppressFocus) return;
      
      var panel = $("detailPanel");
      var detailOpen = panel && !panel.classList.contains('hidden');
      if (!detailOpen) {
        scrollActiveCellIntoView();
      }
      scrollActiveItemIntoView();
    }, 80);
  }

  function saveViewScroll_() {
    state._savedWindowScrollY = window.scrollY || 0;
    state._savedWindowScrollX = window.scrollX || 0;
    var ov = $('overviewTableWrap');
    if (ov) {
      state._savedOverviewScrollLeft = ov.scrollLeft || 0;
      state._savedOverviewScrollTop = ov.scrollTop || 0;
    }
    var cross = $('crossSection');
    if (cross) {
      state._savedCrossScrollLeft = cross.scrollLeft || 0;
      state._savedCrossScrollTop = cross.scrollTop || 0;
    }
    
    var anchorKey = state.movingKey || state.activePalletKey || '';
    state._scrollAnchor = null;
    if (cross && anchorKey) {
      var el = null;
      var nodes = cross.querySelectorAll('.pallet[data-key]');
      for (var i = 0; i < nodes.length; i++) {
        if (nodes[i].getAttribute('data-key') === anchorKey) { el = nodes[i]; break; }
      }
      if (el) {
        var cRect = cross.getBoundingClientRect();
        var eRect = el.getBoundingClientRect();
        state._scrollAnchor = {
          key: anchorKey,
          offsetInView: eRect.top - cRect.top,
          crossLeft: cross.scrollLeft || 0
        };
      }
    }
  }

  function restoreViewScroll_() {
    var y = state._savedWindowScrollY;
    var x = state._savedWindowScrollX;
    if (typeof y === 'number') window.scrollTo(x || 0, y);
    var ov = $('overviewTableWrap');
    if (ov) {
      if (typeof state._savedOverviewScrollLeft === 'number') ov.scrollLeft = state._savedOverviewScrollLeft;
      if (typeof state._savedOverviewScrollTop === 'number') ov.scrollTop = state._savedOverviewScrollTop;
    }
    var cross = $('crossSection');
    if (!cross) return;
    var a = state._scrollAnchor;
    if (a && a.key) {
      var el = cross.querySelector('.pallet.wiggling');
      if (!el) {
        var nodes = cross.querySelectorAll('.pallet[data-key]');
        for (var i = 0; i < nodes.length; i++) {
          if (nodes[i].getAttribute('data-key') === a.key) { el = nodes[i]; break; }
        }
      }
      if (el && typeof a.offsetInView === 'number') {
        var top = el.getBoundingClientRect().top - cross.getBoundingClientRect().top + cross.scrollTop;
        cross.scrollTop = Math.max(0, top - a.offsetInView);
        cross.scrollLeft = typeof a.crossLeft === 'number' ? a.crossLeft : (state._savedCrossScrollLeft || 0);
        return;
      }
    }
    if (typeof state._savedCrossScrollLeft === 'number') cross.scrollLeft = state._savedCrossScrollLeft;
    if (typeof state._savedCrossScrollTop === 'number') cross.scrollTop = state._savedCrossScrollTop;
  }


  function renderOverviewTable() {
    const zoneView = state.activeZoneView;
    if (!zoneView || !zoneView.slots || !zoneView.slots.length) {
      $("overviewTableWrap").innerHTML = '<div class="empty">這個區域沒有可用格位資料</div>';
      return;
    }

    if ($("overviewMeta")) $("overviewMeta").textContent = '';

    const header = zoneView.slots.map(slot => {
      const isActive = slot.slotId === state.activeSlot;
      const dot = isActive ? '<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#f04242;margin-left:5px;vertical-align:middle;box-shadow:0 0 6px rgba(240,66,66,.7)"></span>' : '';
      return '<th' + (isActive ? ' style="background:#1a2f4a;"' : '') + '><div class="slot-head"><strong>' + esc(slot.slotId) + dot + '</strong><small>' + esc(slot.palletCount) + ' 板 / 高 ' + esc(slot.maxLevel) + '</small></div></th>';
    }).join('');

    const rows = [];
    for (let depth = 1; depth <= zoneView.maxDepth; depth += 1) {
      const cells = zoneView.slots.map(slot => {
        const depthData = depthDataOf(slot, depth);
        if (!depthData || !depthData.pallets || !depthData.pallets.length) {
          return '<td class="overview-cell"><div class="cell-empty"></div></td>';
        }
        const pallets = sortedPallets(depthData);
        const query = currentSearchQuery();
        const slotDepthHits = searchSlotDepthSet();
        const lineHtml = pallets.map((row, idx) => {
          const hit = rowMatchesQuery(row, query) ? 'hit' : '';
          const isRed = row.BgColor === 'RED' || row.Status === '混板/散板';
          const isYellow = row.BgColor === 'YELLOW';
          const isGreen = row.BgColor === 'GREEN';
          const colorCls = isRed ? 'red-pallet' : isYellow ? 'yellow-pallet' : isGreen ? 'green-pallet' : '';
          const statusBadge = isRed ? '<span class="status-tag red">散板</span>' : isYellow ? '<span class="status-tag yellow">散板</span>' : isGreen ? '<span class="status-tag green">專案</span>' : '';
          const movedCls = isRecentlyMoved(row) ? 'just-moved' : '';
          var batchHtml = hasSearchQuery(query) ? '' : ('<div class="cell-batch-badge">' + esc(row.Batch || '-') + '</div>');
          var hitTag = hit ? '<span class="status-tag yellow">搜到</span>' : '';
          return '<div class="cell-line ' + hit + ' ' + colorCls + ' ' + movedCls + '"><div class="cell-main"><div class="cell-sku">' + esc(row.SKU || '-') + ' ' + statusBadge + hitTag + '</div></div>' + batchHtml + '</div>';
        }).join('');
        const hitKey = [state.activeSheet, slot.slotId, depth].join('||');
        const anyHit = hasSearchQuery(query) && slotDepthHits.has(hitKey) ? 'search-hit-frame' : '';
        const active = state.activeSlot === slot.slotId && Number(state.activeDepth) === Number(depth) ? 'active' : '';
        const area = (state.activeSheet || '').replace(/-/g, '_');
        const lv = v => '<span class="cf-val">' + esc(String(v)) + '</span>';
        const ll = l => '<span class="cf-lbl">' + l + '</span>';
        const locFoot = lv(area) + ll('_') + lv(slot.slotId) + ll('列_') + lv(depth) + ll('排');
        return '<td class="overview-cell"><button class="cell-btn ' + active + ' ' + anyHit + '" data-slot="' + esc(slot.slotId) + '" data-depth="' + esc(depth) + '" onclick="selectCell(' + JSON.stringify(slot.slotId) + ',' + depth + '); return false;"><div class="cell-lines">' + lineHtml + '</div><div class="cell-foot"><span class="cf-loc">' + locFoot + '</span><span>' + esc(pallets.length) + '板</span></div></button></td>';
      }).join('');
      rows.push('<tr>' + cells + '</tr>');
    }

    $("overviewTableWrap").innerHTML = '<table class="overview-table"><thead><tr>' + header + '</tr></thead><tbody>' + rows.join('') + '</tbody></table>';
    applyZoom();
    renderMinimapSvg();
  }

  function depthLabel(depth) {
    const map = ['', '第一排', '第二排', '第三排', '第四排', '第五排', '第六排', '第七排', '第八排', '第九排', '第十排'];
    return map[depth] || ('第' + depth + '排');
  }

  function selectCell(slotId, depth) {
    saveViewScroll_();
    state.activeSlot = slotId;
    state.activeDepth = Number(depth || 0);
    state.activePalletKey = '';
    state.activeItemKey = '';
    state._suppressFocus = true;
    renderOverviewTable();
    renderDetailPanel();
    if (isMobile()) {
      document.body.style.overflow = 'hidden';
    }
    setTimeout(function(){ state._suppressFocus = false; }, 300);
  }

  function closeDetail() {
    state.activeSlot = '';
    state.activeDepth = 0;
    state.activePalletKey = '';
    state.activeItemKey = '';
    var panel = $("detailPanel");
    if (panel) {
      panel.classList.add("hidden");
      panel.classList.remove('show-edit-card', 'move-active');
    }
    $("detailBackdrop").classList.add("hidden");
    document.body.style.overflow = '';
    state._suppressFocus = true;
    renderOverviewTable();
    restoreViewScroll_();
    setTimeout(function() {
      restoreViewScroll_();
      state._suppressFocus = false;
    }, 50);
  }

  function buildPalletGroups_(pallets) {
    var groups = [];
    var lastGid = null;
    pallets.forEach(function(row) {
      var gid = row.PalletGroupId || row.PalletKey;
      if (gid !== lastGid) { groups.push({ groupId: gid, pallets: [] }); lastGid = gid; }
      groups[groups.length - 1].pallets.push(row);
    });
    return groups;
  }

  function renderDetailPanel() {
    const panel = $("detailPanel");
    const backdrop = $("detailBackdrop");
    const zoneView = state.activeZoneView;
    const slot = slotById(state.activeSlot);

    if (!zoneView || !slot || !state.activeDepth) {
      $("slotTitle").textContent = '剖面圖';
      $("slotMeta").textContent = '先從俯視圖點一個格子';
      $("crossSection").innerHTML = '<div class="empty">上方俯視圖點格子後，這裡才會顯示由下到上的堆疊剖面。</div>';
      panel.classList.add('hidden');
      panel.classList.remove('move-active');
      if (isMobile()) backdrop.classList.add('hidden');
      return;
    }

    panel.classList.remove('hidden');
    panel.classList.toggle('move-active', !!state.movingKey);
    if (isMobile()) backdrop.classList.remove('hidden'); else backdrop.classList.add('hidden');

    $("slotTitle").textContent = '';
    var _lv = function(v) { return '<span class="loc-val">' + esc(String(v)) + '</span>'; };
    var _ll = function(l) { return '<span class="loc-label">' + l + '</span>'; };
    var _sm = (state.activeSheet || '').match(/^([A-C])-([A-H])區$/);
    var _locHtml;
    if (_sm) {
      _locHtml = '<span class="loc-line1">' + _lv(_sm[1]) + _ll('倉') + _lv(_sm[2]) + _ll('區') + '</span>' +
                 '<span class="loc-line2">' + _lv(slot.slotId) + _ll('列') + _lv(state.activeDepth) + _ll('排') + '</span>';
    } else {
      var _area = (state.activeSheet || '').replace(/-/g, '_').replace(/區$/, '');
      _locHtml = '<span class="loc-line1">' + _lv(_area) + _ll('區') + '</span>' +
                 '<span class="loc-line2">' + _lv(slot.slotId) + _ll('列') + _lv(state.activeDepth) + _ll('排') + '</span>';
    }
    var _undo = _undoRedoBtnHtml_('undo', 'banner-undo-btn');
    var _redo = _undoRedoBtnHtml_('redo', 'banner-redo-btn');
    var _zoom = '<span class="cross-zoom-controls"><button type="button" onclick="crossZoomOut()">－</button><button type="button" onclick="crossZoomIn()">＋</button></span>';
    $("slotMeta").innerHTML = '<div class="detail-chrome"><div class="loc-code">' + _locHtml + '</div><div class="detail-chrome-actions">' + _zoom + _undo + _redo + '</div></div>';
    
    var _mw = $('warehouseMapWrap'); if (_mw) _mw.innerHTML = '';

    renderCellItems();
    renderItemDetail();

    const depthMap = {};
    (slot.depths || []).forEach(depth => { depthMap[depth.depth] = depth; });
    const columns = [];
    const isMoveMode = !!state.movingKey;
    const movingRow = state.movingRow;
    const isSameSlot = isMoveMode && movingRow && String(movingRow.Slot) === String(state.activeSlot);
    for (let depth = 1; depth <= zoneView.maxDepth; depth += 1) {
      const depthData = depthMap[depth] || { depth, label: depthLabel(depth), pallets: [], maxPallets: 0 };
      const selectedDepth = Number(depth) === Number(state.activeDepth) ? 'selected' : '';
      const sortedPallets = (depthData.pallets || []).slice().sort((a, b) => a.Level - b.Level);

      const maxP = Number(depthData.maxPallets) || 0;
      const isSourceDepth = isSameSlot && movingRow && Number(movingRow.Depth) === Number(depth);
      const effectiveCount = sortedPallets.length - (isSourceDepth ? 1 : 0);
      const isFull = isMoveMode && maxP > 0 && effectiveCount >= maxP;
      const depthExists = (maxP > 0 || sortedPallets.length > 0);

      var stackInner = '';
      var viewGroups = buildPalletGroups_(sortedPallets);
      if (isMoveMode) {
        if (depthExists) {
          
          stackInner += '<div class="drop-zone drop-zone-flowless" data-depth="' + depth + '" data-level="1" role="button" tabindex="0" onclick="executeDirectMove(state.activeSlot,' + depth + ',1); return false;">放這裡</div>';
          var mvLvCnt = 0;
          viewGroups.forEach(function(group) {
            var isMovingGroup = state.movingGroupKeys.length > 0 &&
              group.pallets.some(function(r) { return state.movingGroupKeys.indexOf(r.PalletKey) >= 0; });
            var gpHtml = group.pallets.map(function(row) {
              var wiggle = isMovingGroup ? ' wiggling' : '';
              var isRed = row.BgColor === 'RED' || row.Status === '混板/散板';
              var isYellow = row.BgColor === 'YELLOW';
              var isGreen = row.BgColor === 'GREEN';
              var tag = isRed ? ' <span class="status-tag red" style="font-size:9px;padding:0 3px">散板</span>' : isYellow ? ' <span class="status-tag yellow" style="font-size:9px;padding:0 3px">散板</span>' : isGreen ? ' <span class="status-tag green" style="font-size:9px;padding:0 3px">專案</span>' : '';
              var movedCls = isRecentlyMoved(row) ? ' just-moved' : '';
              var timeHtml = row.UpdatedAt ? '<span class="pallet-card-time" style="color:#7ff0a6;font-size:10px;font-weight:800;margin-left:4px">🕒 ' + esc(formatMoveTime(row.UpdatedAt)) + '</span>' : '';
              return '<button class="pallet ' + paletteClass(row) + wiggle + movedCls + '" data-key="' + esc(row.PalletKey || '') + '">' +
                '<div class="pallet-sku">' + skuHtml(row.SKU || '-') + tag + '</div>' +
                '<div class="pallet-meta"><span>' + esc(row.Batch || '-') + '</span><span>' + esc(formatPalletQty_(row)) + timeHtml + '</span></div>' +
                '</button>';
            }).join('');
            if (group.pallets.length > 1) {
              stackInner += '<div class="pallet-group' + (isMovingGroup ? ' group-moving' : '') + '">' + gpHtml + '</div>';
            } else {
              stackInner += gpHtml;
            }
            mvLvCnt += group.pallets.length;
            var nextLv2 = mvLvCnt + 1;
            stackInner += '<div class="drop-zone drop-zone-flowless" data-depth="' + depth + '" data-level="' + nextLv2 + '" role="button" tabindex="0" onclick="executeDirectMove(state.activeSlot,' + depth + ',' + nextLv2 + '); return false;">放這裡</div>';
          });
        } else {
          stackInner = '<div class="drop-zone drop-zone-new" data-depth="' + depth + '" data-level="1" role="button" tabindex="0" onclick="executeDirectMove(state.activeSlot,' + depth + ',1); return false;">+ 新增此排</div>';
        }
      } else {
        stackInner = viewGroups.map(function(group) {
          var palletHtml = group.pallets.map(function(row) {
            var selected = row.PalletKey === state.activePalletKey ? 'selected' : '';
            var isRed = row.BgColor === 'RED' || row.Status === '混板/散板';
            var isYellow = row.BgColor === 'YELLOW';
            var isGreen = row.BgColor === 'GREEN';
            var tag = isRed ? ' <span class="status-tag red" style="font-size:9px;padding:0 3px">散板</span>' : isYellow ? ' <span class="status-tag yellow" style="font-size:9px;padding:0 3px">散板</span>' : isGreen ? ' <span class="status-tag green" style="font-size:9px;padding:0 3px">專案</span>' : '';
            var movedCls = isRecentlyMoved(row) ? ' just-moved' : '';
            var timeHtml = row.UpdatedAt ? '<span class="pallet-card-time" style="color:#7ff0a6;font-size:10px;font-weight:800;margin-left:4px">🕒 ' + esc(formatMoveTime(row.UpdatedAt)) + '</span>' : '';
            return '<button class="pallet ' + paletteClass(row) + ' ' + selected + movedCls + '" data-key="' + esc(row.PalletKey || '') + '" onclick="onPalletTap(' + JSON.stringify(row.PalletKey || '') + '); return false;"><div class="pallet-sku">' + skuHtml(row.SKU || '-') + tag + '</div><div class="pallet-meta"><span>' + esc(row.Batch || '-') + '</span><span>' + esc(formatPalletQty_(row)) + timeHtml + '</span></div></button>';
          }).join('');
          if (group.pallets.length > 1) {
            return '<div class="pallet-group">' + palletHtml + '</div>';
          }
          return palletHtml;
        }).join('');
      }

      var capBadge = '';
      if (maxP > 0) {
        var capClass = isMoveMode ? (isFull ? ' cap-full' : (effectiveCount >= maxP - 1 ? ' cap-warn' : '')) : '';
        capBadge = '<span class="depth-cap' + capClass + '">' + sortedPallets.length + '/' + maxP + '</span>';
      }

      const fullClass = (isMoveMode && isFull) ? ' depth-full' : '';
      columns.push('<div class="depth-col ' + selectedDepth + fullClass + '"><div class="depth-col-head">' + esc(depthData.label) + capBadge + '</div><div class="stack">' + stackInner + '</div></div>');
    }

    var gridClass = isMoveMode ? 'cross-grid move-mode' : 'cross-grid';
    
    var _sm3 = (state.activeSheet || '').match(/^([A-C])-([A-H])區$/);
    var _slotLabel;
    if (_sm3) {
      _slotLabel = _sm3[1] + '倉' + _sm3[2] + '區 <strong>' + esc(state.activeSlot) + '</strong> 列';
    } else {
      _slotLabel = esc(state.activeSheet || '') + ' <strong>' + esc(state.activeSlot) + '</strong> 列';
    }
    // @221: keep zoom/undo only in slotMeta detail-chrome — no inner cross-slot-banner controls
    $("crossSection").innerHTML = '<div class="' + gridClass + '">' + columns.join('') + '</div>';
    applyCrossZoom();

    
    document.querySelectorAll('.move-bar').forEach(function(el){ el.remove(); });
    document.body.classList.toggle('has-move-bar', !!isMoveMode);
    if (isMoveMode) {
      var srcRow = state.movingRow;
      var groupTag = state.movingGroupKeys.length > 1 ? ' <span class="move-bar-group-tag">棧板組×' + state.movingGroupKeys.length + '</span>' : '';
      var canUndo = _history && _history.canUndo;
      var moveBarHtml = '<div class="move-bar" id="moveBarFixed">' +
        '<span class="move-bar-sku">' + esc(srcRow ? srcRow.SKU || '-' : '-') + groupTag + '</span>' +
        '<button type="button" class="move-bar-undo" onclick="doUndo()" ' + (canUndo ? '' : 'disabled') + '>還原</button>' +
        '<button type="button" class="move-bar-slot-btn" onclick="openMoveSlotPicker()">移動到其它列</button>' +
        '<button type="button" class="move-bar-cancel" onclick="cancelMoveMode()">取消</button>' +
        '</div>';
      document.body.insertAdjacentHTML('beforeend', moveBarHtml);
    }

    focusSearchTarget();
  }

  function renderCellItems() {
    const items = currentDepthPallets();
    const q = currentSearchQuery();
    if (!items.length) {
      $("cellItems").innerHTML = '<div class="empty">這一格沒有可用 item</div>';
      return;
    }
    if (!state.activeItemKey) state.activeItemKey = items[0].PalletKey || '';
    $("cellItems").innerHTML = items.map((row, idx) => {
      const active = row.PalletKey === state.activeItemKey ? 'active' : '';
      const hit = rowMatchesQuery(row, q) ? 'pulse' : '';
      const pz = row.PiecesPerBox ? '<span class="chip-pz"> · ' + esc(String(row.PiecesPerBox)) + 'pz/箱</span>' : '';
      const qsBox = qtyStatusHtml(row.BoxQtyFontColor);
      const qsPiece = qtyStatusHtml(row.PieceQtyFontColor);
      const isRed = row.BgColor === 'RED' || row.Status === '混板/散板';
      const isYellow = row.BgColor === 'YELLOW';
      const isGreen = row.BgColor === 'GREEN';
      const statusTag = isRed ? '<span class="status-tag red" style="margin-left:4px">散板</span>' : isYellow ? '<span class="status-tag yellow" style="margin-left:4px">散板</span>' : isGreen ? '<span class="status-tag green" style="margin-left:4px">專案</span>' : '';
      const qsTag = (qsBox || qsPiece || '') + statusTag;
      const movedCls = isRecentlyMoved(row) ? 'just-moved' : '';
      return '<button class="item-chip ' + active + ' ' + hit + ' ' + movedCls + '" data-key="' + esc(row.PalletKey || '') + '" onclick="selectItem(' + JSON.stringify(row.PalletKey || '') + '); return false;"><div class="item-chip-top"><strong>' + skuHtml(row.SKU || '-') + '</strong><span class="item-chip-batch">' + esc(row.Batch || '-') + pz + '</span></div><div class="item-chip-bottom"><span>' + esc(depthLabel(row.Depth || state.activeDepth)) + '</span><span>第 ' + esc(idx + 1) + ' 板' + qsTag + '</span></div></button>';
    }).join('');
  }

  function selectItem(palletKey) {
    state.activeItemKey = palletKey;
    state.activePalletKey = palletKey;
    renderCellItems();
    renderItemDetail();
    renderDetailPanel();
  }

  function renderItemDetail() {
    var detailEl = $("itemDetail");
    if (!detailEl) return;
    
    if (state.movingKey) {
      detailEl.className = 'item-detail empty';
      detailEl.innerHTML = '';
      detailEl.style.display = 'none';
      return;
    }
    detailEl.style.display = '';
    var items = currentDepthPallets();
    var rawRow = items.find(item => item.PalletKey === state.activeItemKey)
      || items.find(item => item.PalletKey === state.activePalletKey)
      || null;
    
    if (!rawRow) {
      detailEl.className = 'item-detail empty';
      detailEl.innerHTML = isMobile()
        ? '點選上方棧板查看資訊；長按可移動'
        : '先點一個 item 看完整資料';
      return;
    }
    const row = enrichRowSpecs(rawRow);
    if (!row) {
      $("itemDetail").className = 'item-detail empty';
      $("itemDetail").innerHTML = '先點一個 item 看完整資料';
      return;
    }
    state.activeItemKey = row.PalletKey || '';
    state.activePalletKey = row.PalletKey || '';

    const boxQty = row.BoxQty != null ? Number(row.BoxQty) : 0;
    const pieceQty = row.PieceQty != null ? Number(row.PieceQty) : 0;
    const kgBox = (row.KgPerBox != null && row.KgPerBox !== '') ? Math.ceil(Number(row.KgPerBox)) + ' KG' : '-';
    const kgPallet = (row.KgPerPallet != null && row.KgPerPallet !== '') ? Math.ceil(Number(row.KgPerPallet)) + ' KG' : '-';
    const pzStr = row.PiecesPerBox ? String(row.PiecesPerBox) + ' pz/箱' : '';
    const rawImg = row.SinglePieceImage || ((row.Branches || [])[0] || {}).SinglePieceImage || '';
    const imgUrl = driveThumbUrl(rawImg);
    const imgHtml = imgUrl ? '<div class="item-img-wrap"><img class="item-img" src="' + esc(imgUrl) + '" alt="' + esc(row.SKU || '') + '" loading="lazy" onerror="this.parentNode.style.display=\'none\'"></div>' : '';

    
    var _lp = function(v,l){ return '<span class="loc-val">'+esc(String(v))+'</span><span class="loc-label">'+l+'</span>'; };
    var _sm2 = (row.Sheet||'').match(/^([A-C])-([A-H])區$/);
    var locHtml;
    if (_sm2) {
      locHtml = _lp(_sm2[1],'倉') + _lp(_sm2[2],'區') + _lp(row.Slot||'-','列') + _lp(row.Depth||0,'排') + _lp(row.Level||'-','層');
    } else {
      var _a2 = (row.Sheet||'').replace(/-/g,'_').replace(/區$/,'');
      locHtml = _lp(_a2,'區') + _lp(row.Slot||'-','列') + _lp(row.Depth||0,'排') + _lp(row.Level||'-','層');
    }

    $("itemDetail").className = 'item-detail';
    $("itemDetail").innerHTML =
      '<div class="item-summary">' +
        '<div class="item-sum-row1">' +
          '<span class="item-sum-sku">' + esc(row.SKU || '-') + '</span>' +
          '<span class="item-sum-batch"><span class="batch-label">批號</span>' + esc(row.Batch || '-') + '</span>' +
        '</div>' +
        '<div class="item-sum-qty">' +
          '<input id="inlineBoxQty" type="number" inputmode="numeric" min="0" step="1" class="qty-input qty-box-input" value="' + esc(boxQty) + '" title="箱數">' +
          '<small style="color:#68c8ff;font-size:14px;font-weight:700;align-self:flex-end;padding-bottom:4px">箱' + qtyStatusHtml(row.BoxQtyFontColor) + '</small>' +
          '<input id="inlinePieceQty" type="number" inputmode="numeric" min="0" step="1" class="qty-input qty-piece-input" value="' + esc(pieceQty) + '" title="片數">' +
          '<small style="color:#7ff0a6;font-size:14px;font-weight:700;align-self:flex-end;padding-bottom:4px">片' + qtyStatusHtml(row.PieceQtyFontColor) + '</small>' +
          '<button class="qty-save-btn" onclick="saveInlineQty(' + JSON.stringify(row.PalletKey || '') + ')">💾 儲存</button>' +
        '</div>' +
        '<div class="item-sum-loc-row">' +
          '<span class="loc-code">' + locHtml + '</span>' +
          (pzStr ? '<span class="loc-pz">' + esc(pzStr) + '</span>' : '') +
          '<span class="move-time-tag" style="color:#7ff0a6;font-size:12px;font-weight:700;margin-left:10px">🕒 ' + esc(formatMoveTime(row.UpdatedAt)) + '</span>' +
        '</div>' +
        '<div class="item-sum-actions" style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">' +
          '<button type="button" class="detail-toggle" style="margin:0" onclick="openEditByKey(' + JSON.stringify(row.PalletKey || '') + ')">編輯此板</button>' +
          '<button type="button" class="detail-toggle" style="margin:0;background:#1b3252;border-color:#3b659c;color:#7ec0ff" onclick="startMoveMode(' + JSON.stringify(row.PalletKey || '') + ')">🚚 移動</button>' +
          '<button id="itemDetailToggle" class="detail-toggle" style="margin:0;margin-left:auto" onclick="toggleItemSpecs()">完整資訊 ▼</button>' +
        '</div>' +
      '</div>' +
      '<div class="item-specs hidden" id="itemSpecs">' +
        imgHtml +
        '<div class="detail-grid">' +
          '<div class="detail-box"><small>品牌</small><strong>' + esc(detailValue(row.Brand)) + '</strong></div>' +
          '<div class="detail-box"><small>系列</small><strong>' + esc(detailValue(row.Series || row.ChineseSeries)) + '</strong></div>' +
          '<div class="detail-box detail-box-wide"><small>原文名稱</small><strong>' + esc(detailValue(row.OriginalName)) + '</strong></div>' +
          '<div class="detail-box"><small>尺寸</small><strong>' + esc(detailValue(row.Size)) + '</strong></div>' +
          '<div class="detail-box"><small>箱裝數</small><strong>' + esc(detailValue(row.PiecesPerBox)) + '</strong></div>' +
          '<div class="detail-box"><small>一板幾箱</small><strong>' + esc(detailValue(row.BoxesPerPallet)) + '</strong></div>' +
          '<div class="detail-box"><small>每箱公斤</small><strong>' + kgBox + '</strong></div>' +
          '<div class="detail-box"><small>一板幾公斤</small><strong>' + kgPallet + '</strong></div>' +
          '<div class="detail-box"><small>漢樺編號</small><strong>' + esc(detailValue(row.HanhwaCode)) + '</strong></div>' +
          '<div class="detail-box"><small>狀態</small><strong>' + ((row.BgColor === 'RED' || row.BgColor === 'YELLOW' || row.Status === '混板/散板') ? '<span class="status-tag red">散板 (拆過)</span>' : row.BgColor === 'GREEN' ? '<span class="status-tag green">專案庫存</span>' : esc(detailValue(row.IsLastPallet ? '最後一板' : row.Status))) + '</strong></div>' +
          '<div class="detail-box detail-box-wide"><small>最後移動時間</small><strong style="color:#7ff0a6;font-size:14px">🕒 ' + esc(formatMoveTime(row.UpdatedAt)) + '</strong></div>' +
        '</div>' +
      '</div>';
  }

  function renderSearch() {
    const q = currentSearchQuery();
    const wrap = $("searchWrap");
    if (wrap) wrap.classList.add("hidden");
    if ($("searchResults")) $("searchResults").innerHTML = "";

    var hint = $("searchHint");
    var pickBar = $("searchPickBar");
    var raw = (q.rawSku || "").trim();

    
    if (state.searchPick && state.searchPick.sku) {
      var ps = String(state.searchPick.sku).toLowerCase();
      if (raw && ps !== raw && raw.length < ps.length && ps.indexOf(raw) < 0 && !/^\d{5}$/.test(raw)) {
        
      }
      if (raw && ps !== raw && !ps.endsWith(raw) && raw !== ps && !/^\d{5}$/.test(raw) && ps.indexOf(raw) < 0) {
        state.searchPick = { sku: '', batch: '' };
      }
    }

    if (!raw && !(q.rawBatch)) {
      state.searchPick = { sku: '', batch: '' };
      if (hint) hint.textContent = "";
      if (pickBar) pickBar.innerHTML = "";
      renderZoneChips();
      renderOverviewTable();
      return;
    }

    if (!state.searchReady) {
      if (hint) hint.textContent = "索引載入中…";
      if (pickBar) pickBar.innerHTML = "";
      setStatus("搜尋索引載入中，請稍候", "loading");
      renderZoneChips();
      renderOverviewTable();
      return;
    }

    
    if (!state.searchPick.sku) {
      var cands = uniqueSkuCandidates_(raw);
      if (hint) {
        hint.textContent = cands.length
          ? ("符合 " + cands.length + " 個編號，請點選；區域黃框＝有貨")
          : "找不到符合的編號";
      }
      if (pickBar) {
        if (!cands.length) pickBar.innerHTML = "";
        else {
          pickBar.innerHTML = '<div class="pick-label">選擇完整編號</div><div class="pick-row">' +
            cands.map(function(c) {
              var cc = companyClass(c.company);
              var co = c.company ? ('<small>' + esc(c.company) + '</small>') : '';
              return '<button type="button" class="sku-pick-chip ' + cc + '" onclick="selectSearchSku(' + JSON.stringify(c.sku) + ')">' +
                '<strong>' + esc(c.sku) + '</strong>' + co + '<span class="pick-count">' + c.count + '</span></button>';
            }).join('') + '</div>';
        }
      }
      
      renderZoneChips();
      renderOverviewTable();
      return;
    }

    
    var batches = batchesForSku_(state.searchPick.sku);
    if (hint) {
      hint.textContent = state.searchPick.batch
        ? ("編號 " + state.searchPick.sku + "／批號 " + state.searchPick.batch)
        : ("編號 " + state.searchPick.sku + "：選批號，或不選＝顯示全部");
    }
    if (pickBar) {
      pickBar.innerHTML =
        '<div class="pick-label"><button type="button" class="pick-back" onclick="clearSearchPick()">← 重選編號</button> 批號</div>' +
        '<div class="pick-row">' +
        '<button type="button" class="batch-pick-chip' + (!state.searchPick.batch ? ' selected' : '') + '" onclick="selectSearchBatch(' + JSON.stringify('') + ')">全部批號</button>' +
        batches.map(function(b) {
          var sel = state.searchPick.batch === b.batch ? ' selected' : '';
          return '<button type="button" class="batch-pick-chip' + sel + '" onclick="selectSearchBatch(' + JSON.stringify(b.batch) + ')">' +
            esc(b.batch) + '<span class="pick-count">' + b.count + '</span></button>';
        }).join('') + '</div>';
    }

    renderZoneChips();
    renderOverviewTable();
    var matches = searchMatches();
    var hit0 = matches.find(function(r){ return r.Sheet === state.activeSheet; }) || matches[0];
    if (hint && hit0) {
      var zoneLabel = hit0.Sheet || '';
      if (state.searchPick.batch) {
        hint.textContent = "編號 " + state.searchPick.sku + "／批號 " + state.searchPick.batch + " → " + zoneLabel;
      } else {
        hint.textContent = "編號 " + state.searchPick.sku + "：選批號，或不選＝顯示全部 → 命中區 " + zoneLabel;
      }
    }
    setStatus(matches.length ? ("找到 " + matches.length + " 筆，俯視圖黃框閃爍" + (hit0 && hit0.Sheet ? ("（" + hit0.Sheet + "）") : "")) : "此編號目前無庫存列", matches.length ? "ok" : "err");

    setTimeout(async function() {
      var hit = matches.find(function(r){ return r.Sheet === state.activeSheet; }) || matches[0];
      if (!hit) return;
      try {
        if (hit.Sheet && hit.Sheet !== state.activeSheet) {
          await loadZone(hit.Sheet);
        }
        scrollSearchHitIntoView_(hit.Slot, hit.Depth);
      } catch (eNav) { console.warn('search hit nav', eNav); }
    }, 100);
  }

  async function jumpFromSearch(sheetName, slotId, depth, palletKey) {
    await loadZone(sheetName, slotId, depth, palletKey);
    state.activeItemKey = palletKey || state.activeItemKey;
    renderDetailPanel();
    focusSearchTarget();
    if (isMobile()) document.body.style.overflow = 'hidden';
  }

  function enrichRowSpecs(row) {
    if (!row) return row;
    if (row.Brand && row.Series && row.OriginalName && row.Size) return row;
    if (!state.searchRows || !state.searchRows.length) return row;

    const sku = String(row.SKU || '').trim().toLowerCase();
    if (!sku) return row;

    const match = state.searchRows.find(r => {
      const rSku = String(r.SKU || '').trim().toLowerCase();
      const rHanhwa = String(r.HanhwaCode || '').trim().toLowerCase();
      return (rSku && rSku === sku) || (rHanhwa && rHanhwa === sku);
    });

    if (match) {
      if (!row.Brand) row.Brand = match.Brand;
      if (!row.Series) row.Series = match.Series || match.ChineseSeries;
      if (!row.OriginalName) row.OriginalName = match.OriginalName;
      if (!row.Size) row.Size = match.Size;
      if (!row.PiecesPerBox) row.PiecesPerBox = match.PiecesPerBox;
      if (!row.KgPerBox) row.KgPerBox = match.KgPerBox;
      if (!row.BoxesPerPallet) row.BoxesPerPallet = match.BoxesPerPallet;
      if (!row.HanhwaCode) row.HanhwaCode = match.HanhwaCode;
    }
    return row;
  }

  function findRowByKey(palletKey) {
    const zoneView = state.activeZoneView;
    if (!zoneView) return null;
    for (const slot of (zoneView.slots || [])) {
      var found = (slot.pallets || []).find(r => r.PalletKey === palletKey);
      if (found) return enrichRowSpecs(found);
      for (const d of (slot.depths || [])) {
        found = (d.pallets || []).find(r => r.PalletKey === palletKey);
        if (found) return enrichRowSpecs(found);
      }
    }
    return null;
  }

  function onPalletTap(palletKey) {
    if (state.movingKey) return;
    
    if (_mt.suppressTapUntil && Date.now() < _mt.suppressTapUntil) return;
    
    selectItem(palletKey);
    var panel = $('detailPanel');
    if (panel) panel.classList.add('show-edit-card');
    openEditByKey(palletKey);
  }

  function openEditByKey(palletKey) {
    const row = findRowByKey(palletKey);
    if (!row) return;
    state.activePalletKey = palletKey;
    state.editingRow = row;
    $("editMeta").textContent = [row.Sheet, '格 ' + row.Slot, row.DepthLabel || row.Stack, '第 ' + row.Level + ' 層'].join(' / ');
    $("editSku").value = row.SKU || '';
    $("editBatch").value = row.Batch || '';
    if ($("editBrand")) $("editBrand").value = detailValue(row.Brand);
    if ($("editSeries")) $("editSeries").value = detailValue(row.Series || row.ChineseSeries);
    if ($("editOriginalName")) $("editOriginalName").value = detailValue(row.OriginalName);
    if ($("editSize")) $("editSize").value = detailValue(row.Size);
    $("editBoxes").value = Number(row.BoxQty || 0);
    $("editPieces").value = Number(row.PieceQty || 0);
    $("editStatus").value = row.IsLastPallet ? '最後一板' : (row.Status || '正常庫存');
    var pzHint = $("editPzHint");
    if (pzHint) pzHint.textContent = row.PiecesPerBox ? '(' + row.PiecesPerBox + '片/箱)' : '';
    var modal = $("editModal");
    modal.classList.remove("hidden");
    modal.style.display = '';
    modal.style.visibility = '';
    modal.style.pointerEvents = '';
    document.body.style.overflow = 'hidden';
    
    var imgBox = $('editProductImg');
    if (imgBox) {
      var url = row.ImageUrl || row.imageUrl || '';
      if (!url && state.searchRows) {
        var hit = state.searchRows.find(function(r){ return String(r.SKU||'').toLowerCase() === String(row.SKU||'').toLowerCase(); });
        if (hit) url = hit.ImageUrl || hit.imageUrl || '';
      }
      if (url) {
        imgBox.innerHTML = '<img src="' + esc(url) + '" alt="' + esc(row.SKU||'') + '" style="max-width:100%;max-height:160px;border-radius:10px;object-fit:contain;background:#0b1322">';
        imgBox.style.display = '';
      } else {
        imgBox.innerHTML = '<div style="color:var(--muted);font-size:12px;padding:8px 0">（價目表尚無圖片欄可預覽）</div>';
        imgBox.style.display = '';
      }
    }
  }

  function closeEdit(force) {
    
    state.editingRow = null;
    var panel = $('detailPanel');
    if (panel) panel.classList.remove('show-edit-card');
    var modal = $("editModal");
    if (modal) {
      modal.classList.add("hidden");
      
      modal.style.display = 'none';
      modal.style.visibility = 'hidden';
      modal.style.pointerEvents = 'none';
    }
    if (isMobile() && state.activeSlot && state.activeDepth && !force) {
      document.body.style.overflow = 'hidden';
    } else if (!state.activeSlot || !isMobile()) {
      document.body.style.overflow = '';
    }
  }

  function forceCloseAllOverlays() {
    state.saving = false;
    closeEdit(true);
    closeMoveConfirm();
    closeMoveSlotPicker();
    var overlay = $("gridLoadingOverlay");
    if (overlay) overlay.classList.add("hidden");
    document.querySelectorAll('.move-bar').forEach(function(el){ el.remove(); });
    document.body.classList.remove('has-move-bar');
  }

  async function saveEdit() {
    if (state.saving || !state.editingRow) return;
    const oldData = state.editingRow;
    const newData = {
      Sheet: oldData.Sheet,
      SKU: $("editSku").value.trim(),
      Batch: $("editBatch").value.trim(),
      BoxQty: $("editBoxes").value,
      PieceQty: $("editPieces").value,
      Status: $("editStatus").value
    };
    if (!newData.SKU) {
      setStatus("品號不可空白", "bad");
      return;
    }

    state.saving = true;
    setStatus('正在寫回 ' + oldData.Sheet + ' / 格 ' + oldData.Slot + ' / ' + (oldData.DepthLabel || oldData.Stack) + ' / 第 ' + oldData.Level + ' 層...', 'loading');
    showGridLoading('正在更新棧板資料...');
    try {
      const result = await gas("updateWarehousePallet", { oldData, newData, operator: getOperator() });
      markWriteTime_(oldData.Sheet);
      state.activeZoneView = result.zoneView;
      state.editingRow = null;
      $("editModal").classList.add("hidden");
      renderOverviewTable();
      renderDetailPanel();
      setStatus('已寫回：' + newData.SKU + '，並重新載入 ' + result.zoneView.sheet, 'ok');
    } catch (err) {
      var em = (err && err.message) ? err.message : String(err || 'unknown');
      setStatus('更新失敗：' + em, 'bad');
      fail(err);
      try { alert('更新棧板失敗：' + em); } catch (eA) {}
    } finally {
      state.saving = false;
      hideGridLoading();
    }
  }

  async function saveInlineQty(palletKey) {
    if (state.saving) return;
    const row = findRowByKey(palletKey);
    if (!row) { setStatus('找不到棧板資料', 'bad'); return; }
    const boxInput = $('inlineBoxQty');
    const pieceInput = $('inlinePieceQty');
    const newBoxQty = boxInput ? Number(boxInput.value) : Number(row.BoxQty || 0);
    const newPieceQty = pieceInput ? Number(pieceInput.value) : Number(row.PieceQty || 0);
    state.saving = true;
    setStatus('正在寫回 ' + row.Sheet + ' ' + row.Slot + ' L' + row.Level + '...', 'loading');
    showGridLoading('正在更新棧板數量...');
    try {
      const result = await gas("updateWarehousePallet", {
        oldData: row,
        newData: {
          Sheet: row.Sheet,
          SKU: row.SKU || '',
          Batch: row.Batch || '',
          BoxQty: newBoxQty,
          PieceQty: newPieceQty,
          Status: row.IsLastPallet ? '最後一板' : (row.Status || '正常庫存')
        },
        operator: getOperator()
      });
      markWriteTime_(row.Sheet);
      cacheSet('zone_' + row.Sheet, result.zoneView);
      state.activeZoneView = result.zoneView;
      renderOverviewTable();
      renderDetailPanel();
      setStatus('已儲存：' + (row.SKU || row.Batch || ''), 'ok');
    } catch (err) {
      var em = (err && err.message) ? err.message : String(err || 'unknown');
      setStatus('數量儲存失敗：' + em, 'bad');
      fail(err);
      try { alert('數量儲存失敗：' + em); } catch (eA) {}
    } finally {
      state.saving = false;
      hideGridLoading();
    }
  }

  function onSkuInput() {
    var v = ($("searchSku") && $("searchSku").value || "").trim();
    
    if (state.searchPick && state.searchPick.sku && v.toLowerCase() !== String(state.searchPick.sku).toLowerCase()) {
      state.searchPick = { sku: '', batch: '' };
    }
    updateSearchDatalists('sku');
    renderSearch();
  }

  function onBatchInput() {
    updateSearchDatalists('batch');
    renderSearch();
  }

  function updateSearchDatalists(sourceField) {
    if (!state.searchReady || !state.searchRows || !state.searchRows.length) return;
    const skuVal = ($("searchSku") && $("searchSku").value || "").trim().toLowerCase();
    const batchVal = ($("searchBatch") && $("searchBatch").value || "").trim().toLowerCase();

    if (sourceField === 'sku') {
      const matchingRows = skuVal ? state.searchRows.filter(r => rowText(r).includes(skuVal)) : state.searchRows;
      const batches = Array.from(new Set(matchingRows.map(r => String(r.Batch || '').trim()).filter(Boolean))).slice(0, 30);
      const batchDatalist = $("batchDatalist");
      if (batchDatalist) {
        batchDatalist.innerHTML = batches.map(b => '<option value="' + esc(b) + '"></option>').join('');
      }
    }

    if (sourceField === 'batch') {
      const matchingRows = batchVal ? state.searchRows.filter(r => String(r.Batch || '').toLowerCase().includes(batchVal)) : state.searchRows;
      const skus = Array.from(new Set(matchingRows.map(r => String(r.SKU || '').trim()).filter(Boolean))).slice(0, 30);
      const skuDatalist = $("skuDatalist");
      if (skuDatalist) {
        skuDatalist.innerHTML = skus.map(s => '<option value="' + esc(s) + '"></option>').join('');
      }
      if (skus.length === 1 && !skuVal) {
        $("searchSku").value = skus[0];
      }
    }
  }

  function triggerMoveFromEdit() {
    const key = state.activePalletKey;
    closeEdit();
    if (key) {
      startMoveMode(key);
    }
  }

  function setupListeners() {
    $("editModal").addEventListener("click", e => {
      if (e.target.id === "editModal") closeEdit(true);
    });
    document.addEventListener("keydown", function(e) {
      if (e.key === "Escape") forceCloseAllOverlays();
    });
    $("searchSku").addEventListener("input", onSkuInput);
    $("searchBatch").addEventListener("input", onBatchInput);
    $("zoneChips").addEventListener("click", e => { const btn = e.target.closest(".zone-chip[data-sheet]"); if (btn) loadZone(btn.dataset.sheet); });
    $("overviewTableWrap").addEventListener("click", e => { const btn = e.target.closest(".cell-btn[data-slot][data-depth]"); if (btn) selectCell(btn.dataset.slot, Number(btn.dataset.depth)); });
    $("searchResults").addEventListener("click", e => { const btn = e.target.closest(".search-card[data-sheet]"); if (btn) jumpFromSearch(btn.dataset.sheet, btn.dataset.slot, Number(btn.dataset.depth), btn.dataset.key || ''); });
    $("cellItems").addEventListener("click", e => { const btn = e.target.closest(".item-chip[data-key]"); if (btn) selectItem(btn.dataset.key); });
    
    $("crossSection").addEventListener("click", e => {
      var dz = e.target.closest(".drop-zone");
      if (dz && state.movingKey) {
        e.preventDefault();
        e.stopPropagation();
        executeDirectMove(state.activeSlot, Number(dz.dataset.depth), Number(dz.dataset.level) || 1);
        return;
      }
      if (state.movingKey) return;
      const btn = e.target.closest(".pallet[data-key]");
      if (btn) onPalletTap(btn.dataset.key);
    });
    
    

    
    $("crossSection").addEventListener("mousedown", function(e) {
      if (e.button !== 0 || state.saving) return;
      const btn = e.target.closest(".pallet[data-key]");
      if (!btn) return;
      const key = btn.dataset.key;
      _mt.startX = e.clientX;
      _mt.startY = e.clientY;
      if (_mt.timer) clearTimeout(_mt.timer);
      _mt.timer = setTimeout(function() {
        if (state.saving || state.movingKey) return;
        _mt.suppressTapUntil = Date.now() + 700;
        startMoveMode(key);
      }, 500);
    });

    $("crossSection").addEventListener("mousemove", function(e) {
      if (!_mt.timer) return;
      var dx = e.clientX - _mt.startX;
      var dy = e.clientY - _mt.startY;
      if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
        clearTimeout(_mt.timer); _mt.timer = null;
      }
    });

    $("crossSection").addEventListener("mouseup", function() {
      if (_mt.timer) { clearTimeout(_mt.timer); _mt.timer = null; }
    });

    
    $("crossSection").addEventListener("touchstart", function(e) {
      if (state.saving) return;
      const btn = e.target.closest(".pallet[data-key]");
      if (!btn) return;
      const key = btn.dataset.key;
      _mt.startX = e.touches[0].clientX;
      _mt.startY = e.touches[0].clientY;
      if (_mt.timer) clearTimeout(_mt.timer);
      _mt.touchMoved = false;
      _mt.timer = setTimeout(function() {
        if (state.saving || state.movingKey) return;
        _mt.suppressTapUntil = Date.now() + 700;
        startMoveMode(key);
        if (navigator.vibrate) navigator.vibrate(50);
      }, 500);
    }, { passive: true });

    $("crossSection").addEventListener("touchmove", function(e) {
      var dx = e.touches[0].clientX - _mt.startX;
      var dy = e.touches[0].clientY - _mt.startY;
      if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
        _mt.touchMoved = true;
        if (_mt.timer) { clearTimeout(_mt.timer); _mt.timer = null; }
      }
    }, { passive: true });

    $("crossSection").addEventListener("touchend", function() {
      if (_mt.timer) { clearTimeout(_mt.timer); _mt.timer = null; }
    });

    window.addEventListener('resize', () => {
      if (!isMobile()) {
        $("detailBackdrop").classList.add('hidden');
        document.body.style.overflow = '';
      } else if (state.activeSlot && state.activeDepth) {
        $("detailBackdrop").classList.remove('hidden');
        document.body.style.overflow = 'hidden';
      }
    });
  }

  
  document.addEventListener('contextmenu', function(e) {
    if (e.target.closest('.stack, .cell-btn, .overview-table')) e.preventDefault();
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { setupListeners(); boot(); });
  } else {
    setupListeners();
    boot();
  }
